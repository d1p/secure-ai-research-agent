# United States - Wikipedia

## United States

Source: https://en.wikipedia.org/wiki/United_States

| United States of America |  |
|---|---|
| **Motto:** "In God We Trust"<sup>[\[1\]](https://en.wikipedia.org#cite_note-1)</sup> Other traditional mottos:<sup>[\[2\]](https://en.wikipedia.org#cite_note-de_facto_Motto-2)</sup> *E pluribus unum* (Latin) "Out of many, one" *Annuit cœptis* (Latin) "Providence favors our undertakings" *Novus ordo seclorum* (Latin) "New order of the ages" |  |
| **Anthem:** "The Star-Spangled Banner"<sup>[\[3\]](https://en.wikipedia.org#cite_note-3)</sup> |  |
| Capital | Washington, D.C.<sup>[\[a\]](https://en.wikipedia.org#cite_note-4)</sup> 38°53′N 77°1′W / 38.883°N 77.017°W |
| Largest city | New York City<sup>[\[b\]](https://en.wikipedia.org#cite_note-5)</sup> 40°43′N 74°0′W / 40.717°N 74.000°W |
| Official languages | English<sup>[\[c\]](https://en.wikipedia.org#cite_note-officiallanguage-10)</sup> |
| Ethnic groups | **By race:**61.6% White 12.4% Black 6% Asian 1.1% Native American 0.2% Pacific Islander 10.2% two or more races 8.4% other **By origin:**81.3% non-Hispanic or Latino 18.7% Hispanic or Latino |
| Religion (2025)<sup>[\[11\]](https://en.wikipedia.org#cite_note-Gallup-14)</sup> |
65% Christianity
32% Protestantism 20% Catholicism 12% other Christian 1% Mormonism 24% unaffiliated 2% Judaism 6% other religion 3% unanswered |
| Demonym | American<sup>[\[12\]](https://en.wikipedia.org#cite_note-15)</sup><sup>[\[d\]](https://en.wikipedia.org#cite_note-demonym-16)</sup> |
| Government | Federal presidential republic |
|  | Donald Trump |
|  | JD Vance |
|  | Mike Johnson |
|  | John Roberts |
| Legislature | Congress |
|  | Senate |
|  | House of Representatives |
| Independence from Great Britain |  |
|  | July 4, 1776 |
|  | March 1, 1781 |
|  | September 3, 1783 |
|  | March 4, 1789 |
| Area  |  |
| • Total area | 3,796,742 sq mi (9,833,520 km <sup>2</sup>)<sup>[\[13\]](https://en.wikipedia.org#cite_note-CensusGov2010HTML-17)</sup><sup>[\[e\]](https://en.wikipedia.org#cite_note-largestcountry-20)</sup> (4th) |
| • Water (%) | 7.0 <sup>[\[16\]](https://en.wikipedia.org#cite_note-21)</sup> (2010) |
| • Land area | 3,531,905 sq mi (9,147,590 km <sup>2</sup>) (3rd) |
| Population |  |
| • 2025 estimate | 341,784,857 <sup>[\[17\]](https://en.wikipedia.org#cite_note-Vintage2025-22)</sup> |
| • 2020 census | 331,449,281 <sup>[\[18\]](https://en.wikipedia.org#cite_note-23)</sup><sup>[\[f\]](https://en.wikipedia.org#cite_note-pop-24)</sup> (3rd) |
| • Density | 96.8/sq mi (37.4/km <sup>2</sup>) (180th) |
| GDP (PPP) | 2026 estimate |
| • Total | $32.642 trillion <sup>[\[19\]](https://en.wikipedia.org#cite_note-IMFWEO.US-25)</sup><sup>[\[g\]](https://en.wikipedia.org#cite_note-PPP-26)</sup> (2nd) |
| • Per capita | $95,212 <sup>[\[19\]](https://en.wikipedia.org#cite_note-IMFWEO.US-25)</sup> (10th) |
| GDP (nominal) | 2026 estimate |
| • Total | $32.642 trillion <sup>[\[19\]](https://en.wikipedia.org#cite_note-IMFWEO.US-25)</sup> (1st) |
| • Per capita | $95,212 <sup>[\[19\]](https://en.wikipedia.org#cite_note-IMFWEO.US-25)</sup> (8th) |
| Gini (2024) | 41.8 <sup>[\[20\]](https://en.wikipedia.org#cite_note-27)</sup><sup>[\[h\]](https://en.wikipedia.org#cite_note-28)</sup> medium inequality |
| HDI (2023) | 0.938 <sup>[\[21\]](https://en.wikipedia.org#cite_note-UNHDR-29)</sup> very high ( 17th) |
| Currency | U.S. dollar ($) (USD) |
| Time zone | UTC−4 to −12, +10, +11 |
|  | UTC−4 to −10<sup>[\[i\]](https://en.wikipedia.org#cite_note-time-30)</sup> |
| Date format | mm/dd/yyyy <sup>[\[j\]](https://en.wikipedia.org#cite_note-31)</sup> |
| Calling code | +1 |
| ISO 3166 code | US |
| Internet TLD | .us<sup>[\[22\]](https://en.wikipedia.org#cite_note-32)</sup> |

The **United States of America** (**USA**), also known as the **United States** (**U.S.**) or **America**, is a country primarily located in North America.federal republic consisting of 50 states and a federal capital district, Washington, D.C. The 48 contiguous states border Canada to the north and Mexico to the south, with the semi-exclave of Alaska in the northwest and the archipelago of Hawaii in the Pacific Ocean. The United States also asserts sovereignty over five major island territories and various uninhabited islands in Oceania and the Caribbean.<sup>[\[k\]](https://en.wikipedia.org#cite_note-34)</sup> It is a megadiverse country, with the world's fourth-largest total area<sup>[\[l\]](https://en.wikipedia.org#cite_note-39)</sup> and third-largest population, exceeding 341 million.[\[m\]](https://en.wikipedia.org#cite_note-pop_clock-40)

Paleo-Indians migrated from North Asia to North America at least 15,000 years ago and formed various civilizations. Beginning in 1607, British colonization established the Thirteen Colonies. The 18th-century American Enlightenment spread values of republicanism and liberalism there, and clashes with the British Crown over taxation without parliamentary representation, among other denied rights, sparked the American Revolution. Independence from Great Britain was formally declared in the Lee Resolution of July 2, 1776, two days before the Declaration of Independence. Victory in the 1775–1783 Revolutionary War brought international recognition of U.S. sovereignty.

The U.S. expanded westward through the purchase, settlement, and conquest of European- and Indigenous-controlled territory. As more states joined the Union, a sectional division over slavery led 11 Southern states to declare secession and form the Confederate States of America, fighting the Union in the Civil War of 1861–1865. With the United States' victory and reunification, slavery was abolished. By 1900, the U.S. emerged as a great power, a status solidified after its involvement in World War I. Following Japan's attack on Pearl Harbor in 1941, it entered World War II on the Allied side. The war's aftermath left the U.S. and the Soviet Union as rival superpowers, vying for geopolitical dominance during the Cold War. The Soviet Union's collapse in 1991 left the U.S. as the world's sole superpower, although it has faced competition from China in the 2020s.

The U.S. federal government is a republic under the Constitution, which created a separation of powers among legislative, executive, and judicial branches. Executive authority is vested in a president, while Congress is a bicameral national legislature composed of the House of Representatives (a lower house based on population) and the Senate (an upper house based on equal representation for each state). The Supreme Court exercises judicial review, under which it may hold laws or governmental actions unconstitutional. Federalism grants substantial autonomy to the 50 states.

A developed country, the United States ranks high in economic competitiveness, innovation, and higher education. Its economy accounts for over a quarter of nominal global GDP and has been the world's largest since about 1890. The U.S. is the wealthiest country, with the highest disposable household income per capita among OECD members, though its wealth inequality is highly pronounced. American culture, shaped by centuries of immigration, is diverse and globally influential. The U.S. makes up nearly a third of global military spending and is widely considered to have the most powerful armed forces in the world. A member of numerous international organizations, it plays a dominant role in global political, cultural, economic, and military affairs.

## Etymology

Documented use of the phrase "United States of America" dates back to January 2, 1776. On that day, Stephen Moylan, a Continental Army aide to General George Washington, wrote a letter to Joseph Reed, Washington's aide-de-camp, seeking to go "with full and ample powers from the United States of America to Spain" to seek assistance in the Revolutionary War effort.[\[28\]](https://en.wikipedia.org#cite_note-DeLear-20132-41)<sup>[\[29\]](https://en.wikipedia.org#cite_note-42)</sup> The first known public usage is an anonymous essay published in the Williamsburg newspaper *The Virginia Gazette* on April 6, 1776.<sup>[\[28\]](https://en.wikipedia.org#cite_note-DeLear-20132-41)</sup> Sometime on or after June 11, 1776, Thomas Jefferson wrote "United States of America" in a rough draft of the Declaration of Independence,<sup>[\[28\]](https://en.wikipedia.org#cite_note-DeLear-20132-41)</sup> which was adopted by the Second Continental Congress on July 4, 1776.[\[30\]](https://en.wikipedia.org#cite_note-Davis72-43)

The term "United States" and its initialism "U.S.", used as nouns or as adjectives in English, are common short names for the country. The initialism "USA", a noun, is also common.<sup>[\[31\]](https://en.wikipedia.org#cite_note-44)</sup> "United States" and "U.S." are the established terms throughout the U.S. federal government, with prescribed rules.<sup>[\[n\]](https://en.wikipedia.org#cite_note-46)</sup> "The States" is an established colloquial shortening of the name, used particularly from abroad;<sup>[\[33\]](https://en.wikipedia.org#cite_note-47)</sup> "stateside" is the corresponding adjective or adverb.[\[34\]](https://en.wikipedia.org#cite_note-48)

"America" is the feminine form of the first name of *Americus Vesputius*, the Latinized name of Italian explorer Amerigo Vespucci (1454–1512);<sup>[\[o\]](https://en.wikipedia.org#cite_note-49)</sup> it was first used as a place name by the German cartographers Martin Waldseemüller and Matthias Ringmann in 1507.[\[35\]](https://en.wikipedia.org#cite_note-50)<sup>[\[p\]](https://en.wikipedia.org#cite_note-51)</sup> Vespucci proposed that the West Indies discovered by Christopher Columbus in 1492 were part of a previously unknown landmass and not among the Indies at the eastern limit of Asia.[\[36\]](https://en.wikipedia.org#cite_note-FOOTNOTESider2007226-52)[\[37\]](https://en.wikipedia.org#cite_note-53)<sup>[\[38\]](https://en.wikipedia.org#cite_note-locnamingofamerica-54)</sup> In English, the term "America" (used without a qualifier) seldom refers to topics unrelated to the United States. "The Americas" is the general term to describe the totality of the continents of North and South America.[\[39\]](https://en.wikipedia.org#cite_note-FOOTNOTEWilson199327–28-55)

## History

### Indigenous peoples

The first inhabitants of North America migrated from Siberia at least 15,000 years ago, either across the Bering land bridge or along the now-submerged Ice Age coastline.[\[41\]](https://en.wikipedia.org#cite_note-FOOTNOTEErlandsonRickVellanoweth200819-57)<sup>[\[42\]](https://en.wikipedia.org#cite_note-FOOTNOTESavage201155–58-58)</sup> The Clovis culture, which appeared around 11,000 BCE in North America, is believed to be the first widespread culture in the Americas.[\[43\]](https://en.wikipedia.org#cite_note-FOOTNOTEWatersStafford20071122–1126-59)<sup>[\[44\]](https://en.wikipedia.org#cite_note-FOOTNOTEFlannery2015173–185-60)</sup> Over time, Indigenous North American cultures grew increasingly sophisticated, and some, such as the Mississippian culture, developed agriculture, architecture, and complex societies.<sup>[\[45\]](https://en.wikipedia.org#cite_note-FOOTNOTELockard2010315-61)</sup> In the post-archaic period, the Mississippian cultures were located in the midwestern, eastern, and southern regions, and the Algonquian in the Great Lakes region and along the Eastern Seaboard, while the Hohokam culture and Ancestral Puebloans inhabited  the Southwest.[\[46\]](https://en.wikipedia.org#cite_note-FOOTNOTEJohansen200651-62)Native population estimates of what is now the United States before the arrival of European colonizers range from around 500,000[\[47\]](https://en.wikipedia.org#cite_note-FOOTNOTEThornton199834-63)<sup>[\[48\]](https://en.wikipedia.org#cite_note-FOOTNOTEPerdueGreen200540-64)</sup> to nearly 10 million.[\[48\]](https://en.wikipedia.org#cite_note-FOOTNOTEPerdueGreen200540-64)<sup>[\[49\]](https://en.wikipedia.org#cite_note-FOOTNOTEHainesHainesSteckel200012-65)</sup> In 2024, an estimated 3.43 million people in the United States identified as American Indian or Alaska Native alone (thus, identifying with no other racial category) and represented approximately 1% of the U.S. population.<sup>[\[50\]](https://en.wikipedia.org#cite_note-66)</sup> An additional 5.68 million people identified as American Indian or Alaska Native in combination with one or more other races, bringing the total of those identifying as American Indian or Alaska Native to approximately 9.11 million.[\[51\]](https://en.wikipedia.org#cite_note-67)

### European exploration, colonization and conflict (1513–1765)

Christopher Columbus began exploring the Caribbean for Spain in 1492, leading to Spanish-speaking settlements and missions from what are now Puerto Rico and Florida to New Mexico and California. The first Spanish colony in the present-day continental United States was Spanish Florida, chartered in 1513.[\[52\]](https://en.wikipedia.org#cite_note-FOOTNOTEVigil2006329-68)[\[53\]](https://en.wikipedia.org#cite_note-FOOTNOTEHudson2018130-69)[\[54\]](https://en.wikipedia.org#cite_note-FOOTNOTEDavis19325–6-70)<sup>[\[55\]](https://en.wikipedia.org#cite_note-71)</sup> After several settlements failed there due to starvation and disease, Spain's first permanent town, Saint Augustine, was founded in 1565.[\[56\]](https://en.wikipedia.org#cite_note-72)

France established its own settlements in French Florida in 1562, but they were either abandoned (Charlesfort, 1563)<sup>[\[57\]](https://en.wikipedia.org#cite_note-Review-Charlesfort-73)</sup> or destroyed by Spanish raids (Fort Caroline, 1565). Permanent French settlements were founded much later along the Great Lakes (Fort Detroit, 1701), the Mississippi River (St. Louis, 1764) and especially the Gulf of Mexico (New Orleans, 1718).<sup>[\[58\]](https://en.wikipedia.org#cite_note-FOOTNOTEPetto2007125-74)</sup> Early European colonies also included the thriving Dutch colony of New Nederland (settled 1626, present-day New York) and the small Swedish colony of New Sweden (settled 1638 in what became Delaware). British colonization of the East Coast began with the Virginia Colony (1607) and the Plymouth Colony (Massachusetts, 1620).[\[59\]](https://en.wikipedia.org#cite_note-FOOTNOTESeelyeSelby2018344-75)[\[60\]](https://en.wikipedia.org#cite_note-76)

The Mayflower Compact in Massachusetts and the Fundamental Orders of Connecticut established precedents for local representative self-governance and constitutionalism that would develop throughout the American colonies.[\[61\]](https://en.wikipedia.org#cite_note-Remini2–32-77)<sup>[\[62\]](https://en.wikipedia.org#cite_note-Johnson26–302-78)</sup> While European settlers in what is now the United States experienced conflicts with Native Americans, they also engaged in trade, exchanging European tools for food and animal pelts.[\[63\]](https://en.wikipedia.org#cite_note-FOOTNOTERipper20086-79)<sup>[\[q\]](https://en.wikipedia.org#cite_note-83)</sup> Relations ranged from close cooperation to warfare and massacres. The colonial authorities often pursued policies that forced Native Americans to adopt European lifestyles, including conversion to Christianity.[\[67\]](https://en.wikipedia.org#cite_note-FOOTNOTERipper20085-84)<sup>[\[68\]](https://en.wikipedia.org#cite_note-85)</sup> Along the eastern seaboard, settlers trafficked Africans through the Atlantic slave trade, largely to provide manual labor on plantations.[\[69\]](https://en.wikipedia.org#cite_note-FOOTNOTEThomas1997516-86)

The original Thirteen Colonies<sup>[\[r\]](https://en.wikipedia.org#cite_note-87)</sup> that would later found the United States were administered as possessions of the British Empire by Crown-appointed governors,<sup>[\[70\]](https://en.wikipedia.org#cite_note-FOOTNOTEBilhartzElliott2007-88)</sup> though local governments held elections open to most white male property owners.[\[71\]](https://en.wikipedia.org#cite_note-FOOTNOTEWood1998263-89)<sup>[\[72\]](https://en.wikipedia.org#cite_note-FOOTNOTERatcliffe2013220-90)</sup> The colonial population grew rapidly from Maine to Georgia, eclipsing Native American populations;<sup>[\[73\]](https://en.wikipedia.org#cite_note-FOOTNOTEWaltonRockoff200938–39-91)</sup> by the 1770s, the natural increase of the population was such that only a small minority of Americans had been born overseas.<sup>[\[74\]](https://en.wikipedia.org#cite_note-FOOTNOTEWaltonRockoff200935-92)</sup> The colonies' distance from Britain facilitated the entrenchment of self-governance,<sup>[\[75\]](https://en.wikipedia.org#cite_note-FOOTNOTEOtis1764-93)</sup> and the First Great Awakening, a series of Christian revivals, fueled colonial interest in guaranteed religious liberty.[\[76\]](https://en.wikipedia.org#cite_note-FOOTNOTEFoner19984–5-94)

### American Revolution and the early republic (1765–1800)

Following its victory in the French and Indian War, Britain began to assert greater control over local affairs in the Thirteen Colonies, resulting in growing political resistance. One of the primary grievances of the colonists was the denial of their rights as Englishmen, particularly the right to representation in the British government that taxed them. To demonstrate their dissatisfaction and resolve, the First Continental Congress met in 1774 and passed the Continental Association, a colonial boycott of British goods enforced by local "committees of safety" that proved effective. The British attempt to then disarm the colonists resulted in the 1775 Battles of Lexington and Concord, igniting the American Revolutionary War. At the Second Continental Congress, the colonies appointed George Washington Commander-in-Chief of the Continental Army, and created a committee that named Thomas Jefferson to draft the Declaration of Independence. Two days after the Second Continental Congress passed the Lee Resolution to create an independent, sovereign nation, the Declaration was adopted on July 4, 1776.<sup>[\[77\]](https://en.wikipedia.org#cite_note-FOOTNOTEYoungNashRaphael20114–7-95)</sup> The political values of the American Revolution evolved from an armed rebellion demanding reform within an empire to a revolution that created a new social and governing system founded on the defense of liberty and the protection of inalienable natural rights; equality under the law; sovereignty of the people;[\[78\]](https://en.wikipedia.org#cite_note-96)republicanism over monarchy, aristocracy, and other hereditary political power; civic virtue; and an intolerance of political corruption.<sup>[\[79\]](https://en.wikipedia.org#cite_note-FOOTNOTEBuel1972-97)</sup> The Founding Fathers of the United States, who included Washington, Jefferson, John Adams, Benjamin Franklin, Alexander Hamilton, John Jay, James Madison, Thomas Paine, and many others, were inspired by Classical, Renaissance, and Enlightenment philosophies and ideas.[\[80\]](https://en.wikipedia.org#cite_note-98)[\[81\]](https://en.wikipedia.org#cite_note-SEoP-2006-99)

Though in practical effect since its drafting in 1777, the Articles of Confederation were ratified in 1781 and formally established a decentralized government that operated until 1789.<sup>[\[77\]](https://en.wikipedia.org#cite_note-FOOTNOTEYoungNashRaphael20114–7-95)</sup> After the British surrender at the siege of Yorktown in 1781, American sovereignty was internationally recognized by the Treaty of Paris (1783), through which the U.S. also gained territory stretching west to the Mississippi River, north to present-day Canada, and south to Spanish Florida.<sup>[\[82\]](https://en.wikipedia.org#cite_note-100)</sup> The Northwest Ordinance (1787) established the precedent by which the country's territory would expand with the admission of new states, rather than the expansion of existing states.[\[83\]](https://en.wikipedia.org#cite_note-FOOTNOTESatō1886352-101)

The U.S. Constitution was drafted at the 1787 Constitutional Convention to overcome certain limitations of the Articles. It went into effect in 1789, creating a federal republic governed by three separate branches that together formed a system of checks and balances.<sup>[\[84\]](https://en.wikipedia.org#cite_note-FOOTNOTEFoner2020524-102)</sup> George Washington was elected the country's first president under the Constitution, and the Bill of Rights (a series of ten amendments to the Constitution) was adopted in 1791 to allay skeptics' concerns about the power of the more centralized government.[\[85\]](https://en.wikipedia.org#cite_note-FOOTNOTEFoner2020538–540-103)Washington's resignation as Commander-in-Chief after the Revolutionary War and his later refusal to run for a third term as the country's first president established a precedent for the supremacy of civil authority in the United States and the peaceful transfer of power.[\[86\]](https://en.wikipedia.org#cite_note-BoyerJr.20072-104)

### Westward expansion and Civil War (1800–1865)

In the late 18th century, American settlers began to expand westward in larger numbers, many with a sense of manifest destiny.[\[87\]](https://en.wikipedia.org#cite_note-FOOTNOTECarlisleGolson2007238-105)<sup>[\[88\]](https://en.wikipedia.org#cite_note-FOOTNOTEMcPherson198841–46-106)</sup> The Louisiana Purchase of 1803 from France nearly doubled the territory of the United States.[\[89\]](https://en.wikipedia.org#cite_note-107)[\[90\]](https://en.wikipedia.org#cite_note-108)Lingering issues with Britain remained, leading to the War of 1812, which was fought to a draw.[\[91\]](https://en.wikipedia.org#cite_note-FOOTNOTEWait199978-109)Spain ceded Florida and its Gulf Coast territory in 1819.[\[92\]](https://en.wikipedia.org#cite_no

[content truncated; raise max_chars or request the source URL for more]

Sources:
- https://en.wikipedia.org/wiki/In_God_We_Trust
- https://en.wikipedia.org/wiki/E_pluribus_unum
- https://en.wikipedia.org/wiki/Latin_language
- https://en.wikipedia.org/wiki/Annuit_cœptis
- https://en.wikipedia.org/wiki/Novus_ordo_seclorum
- https://en.wikipedia.org/wiki/The_Star-Spangled_Banner
- https://en.wikipedia.org/wiki/Washington,_D.C.
- https://geohack.toolforge.org/geohack.php?pagename=United_States¶ms=38_53_N_77_1_W_
- https://en.wikipedia.org/wiki/New_York_City
- https://geohack.toolforge.org/geohack.php?pagename=United_States¶ms=40_43_N_74_0_W_
- https://en.wikipedia.org/wiki/English_language
- https://en.wikipedia.org/wiki/Ethnic_group
- https://en.wikipedia.org/wiki/White_Americans
- https://en.wikipedia.org/wiki/African_Americans
- https://en.wikipedia.org/wiki/Asian_Americans
- https://en.wikipedia.org/wiki/Native_American
- https://en.wikipedia.org/wiki/Pacific_Islander_Americans
- https://en.wikipedia.org/wiki/Two_or_more_races
- https://en.wikipedia.org/wiki/Race_and_ethnicity_in_the_United_States_census
- https://en.wikipedia.org/wiki/Hispanic_and_Latino_Americans
- https://en.wikipedia.org/wiki/Christianity_in_the_United_States
- https://en.wikipedia.org/wiki/Protestantism_in_the_United_States
- https://en.wikipedia.org/wiki/Catholic_Church_in_the_United_States
- https://en.wikipedia.org/wiki/List_of_Christian_denominations
- https://en.wikipedia.org/wiki/Mormonism
- https://en.wikipedia.org/wiki/Irreligion_in_the_United_States
- https://en.wikipedia.org/wiki/American_Jews
- https://en.wikipedia.org/wiki/Religion_in_the_United_States
- https://en.wikipedia.org/wiki/Demonym
- https://en.wikipedia.org/wiki/Americans
- https://en.wikipedia.org/wiki/Politics_of_the_United_States
- https://en.wikipedia.org/wiki/Presidential_republic
- https://en.wikipedia.org/wiki/Donald_Trump
- https://en.wikipedia.org/wiki/JD_Vance
- https://en.wikipedia.org/wiki/Mike_Johnson
- https://en.wikipedia.org/wiki/John_Roberts
- https://en.wikipedia.org/wiki/United_States_Congress
- https://en.wikipedia.org/wiki/United_States_Senate
- https://en.wikipedia.org/wiki/United_States_House_of_Representatives
- https://en.wikipedia.org/wiki/American_Revolution

[3681 source links omitted by the link cap]
