# product-reviews

## Aurora Desk Lamp

> Synthetic product fixture

Source: https://example.com/product-reviews

$49.99

Rating: 4.6 out of 5 from 1,284 reviews.

## Reviews

Ada: Great light, easy on the eyes.

Ben: The USB-C port stopped working after two months.

Cleo: Best desk lamp for late-night reading.

| Spec | Value |
|---|---|
| Color temperature | 2700-6500 K |
| Warranty | 2 years |
