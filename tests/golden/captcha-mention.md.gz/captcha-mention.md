# CAPTCHA - Wikipedia

## CAPTCHA

Source: https://en.wikipedia.org/wiki/CAPTCHA

A **CAPTCHA** (/ˈkæp.tʃə/ *KAP-chə*), a type of challenge-response Turing test, aims to protect computing  user-interfaces. It attempts to deter  bot attacks and  spam by determining whether a  user is a human.[\[1\]](https://en.wikipedia.org#cite_note-1)

The term "CAPTCHA" was coined in 2003 by Luis von Ahn, Manuel Blum, Nicholas J. Hopper, and John Langford.<sup>[\[2\]](https://en.wikipedia.org#cite_note-abhl-2)</sup> It is a contrived acronym for "**Completely Automated Public Turing test to tell Computers and Humans Apart**".<sup>[\[3\]](https://en.wikipedia.org#cite_note-3)</sup> A historically common type of CAPTCHA (displayed as reCAPTCHA v1) was first invented in 1997 by two groups working in parallel. This form of CAPTCHA requires interpreting a sequence of letters or numbers from a distorted image. Because the test is administered by a computer, in contrast to the standard Turing test that is administered by a human, CAPTCHAs are sometimes described as reverse Turing tests.[\[4\]](https://en.wikipedia.org#cite_note-4)

Two widely-used CAPTCHA services are Google's reCAPTCHA[\[5\]](https://en.wikipedia.org#cite_note-5)<sup>[\[6\]](https://en.wikipedia.org#cite_note-6)</sup> and Intuition Machines' hCaptcha.[\[7\]](https://en.wikipedia.org#cite_note-7)[\[8\]](https://en.wikipedia.org#cite_note-8)Cloudflare, a major website-security service provider, reported in 2021 that it takes the average person approximately 32 seconds to complete a typical CAPTCHA challenge,<sup>[\[9\]](https://en.wikipedia.org#cite_note-9)</sup> although an earlier estimate from Stanford University in 2018 reported a shorter solving-time of about 10 seconds.[\[10\]](https://en.wikipedia.org#cite_note-10)

## Purpose

The purpose of CAPTCHAs is to prevent bots from using services intended for human use, prevent denial-of-service attacks, prevent distortion of collected usage information, prevent automated entry of false information, and prevent data scraping. Many websites use CAPTCHA effectively to prevent bot raiding. CAPTCHAs are designed so that humans can complete them, while most robots cannot.<sup>[\[11\]](https://en.wikipedia.org#cite_note-11)</sup> Newer CAPTCHAs look at the user's behaviour on the internet, to prove that they are a human.<sup>[\[12\]](https://en.wikipedia.org#cite_note-12)</sup> Ideally, a CAPTCHA test only appears if the user's actions resemble those by a bot, such as if they request webpages from suspicious IP addresses, access many pages, or click links too quickly.

It has also been suggested that popular CAPTCHA services such as reCAPTCHA and hCAPTCHA had the dual purpose of serving as public tools to use humans to generate data sets for AI with tasks such as image-labelling.[\[13\]](https://en.wikipedia.org#cite_note-:0-13)[\[14\]](https://en.wikipedia.org#cite_note-14)

## History

Since the 1980s–1990s, users have wanted to make text illegible to computers.<sup>[\[15\]](https://en.wikipedia.org#cite_note-:1-15)</sup> The first such people were hackers, posting about sensitive topics to Internet forums they thought were being automatically monitored on keywords. To circumvent such filters, they replaced a word with look-alike characters. *HELLO* could become `|-|3|_|_()` or `)-(3££0`, and others, such that a filter could not detect *all* of them. This later became known as leetspeak.[\[16\]](https://en.wikipedia.org#cite_note-16)

One of the earliest commercial uses of CAPTCHAs was in the **Gausebeck–Levchin test**. In 2000, idrive.com began to protect its signup page<sup>[\[17\]](https://en.wikipedia.org#cite_note-17)</sup> with a CAPTCHA and prepared to file a patent.<sup>[\[15\]](https://en.wikipedia.org#cite_note-:1-15)</sup> In 2001, PayPal used such tests as part of a fraud prevention strategy in which they asked humans to "retype distorted text that programs have difficulty recognizing".<sup>[\[18\]](https://en.wikipedia.org#cite_note-stringham2015-18)</sup> PayPal co founder and CTO Max Levchin helped commercialize this use. AltaVista implemented an early CAPTCHA scheme to protect against fraudulent account registrations.[\[19\]](https://en.wikipedia.org#cite_note-rg20-19)[\[20\]](https://en.wikipedia.org#cite_note-or19-20)[\[21\]](https://en.wikipedia.org#cite_note-usp98-21)

A popular deployment of CAPTCHA technology, reCAPTCHA, was acquired by Google in 2009.<sup>[\[22\]](https://en.wikipedia.org#cite_note-22)</sup> In addition to preventing bot fraud for its users, Google used reCAPTCHA and CAPTCHA technology to digitize the archives of *The New York Times* and books from Google Books in 2011.<sup>[\[23\]](https://en.wikipedia.org#cite_note-23)</sup> While early versions required users to transcribe words or label traffic images, the current implementation of reCAPTCHA is based on collecting data on the behavior and attributes of the user, e.g. through canvas fingerprinting,<sup>[\[24\]](https://en.wikipedia.org#cite_note-:2-24)</sup> and using this data to assess which users are bots. Image labeling challenges are only presented when the user is determined to be "high-risk". Cloudflare's Turnstile functions similarly and is also widely used.<sup>[\[13\]](https://en.wikipedia.org#cite_note-:0-13)</sup> Mouse movement does not seem to affect reCAPTCHA's risk analysis.[\[24\]](https://en.wikipedia.org#cite_note-:2-24)

In 2026 Google announced that new versions of its reCAPTCHA software would require users to scan a QR-code with their phone, with Android users being required to have Google Play services installed on their phones. This would make solving these captchas impossible on phones without Google Play services (like those running GrapheneOS or LineageOS).[\[25\]](https://en.wikipedia.org#cite_note-25)

## Characteristics

CAPTCHAs are automated, requiring little human maintenance or intervention to administer, producing benefits in cost and reliability.[\[26\]](https://en.wikipedia.org#cite_note-26)

Text-based CAPTCHAs are designed such that they require the simultaneous use of three separate abilities—invariant recognition, segmentation, and parsing to complete the task.[\[27\]](https://en.wikipedia.org#cite_note-27)

- Invariant recognition refers to the ability to recognize letters despite a large amount of variation in their shapes.<sup>[\[28\]](https://en.wikipedia.org#cite_note-28)</sup>
- Segmentation is the ability to separate one letter from another, made difficult in CAPTCHAs.
- Parsing refers to the ability to understand the CAPTCHA holistically, in order to correctly identify each character.<sup>[\[29\]](https://en.wikipedia.org#cite_note-29)</sup>

Each of these problems poses a significant challenge for a computer, even in isolation. Therefore, these three techniques in tandem make CAPTCHAs difficult for computers to solve.[\[30\]](https://en.wikipedia.org#cite_note-bursz-30)

Whilst primarily used for security reasons, CAPTCHAs can also serve as a benchmark task for artificial intelligence technologies. According to an article by Ahn, Blum and Langford,<sup>[\[31\]](https://en.wikipedia.org#cite_note-Ahn2003-31)</sup> "any program that passes the tests generated by a CAPTCHA can be used to solve a hard unsolved AI problem".<sup>[\[32\]](https://en.wikipedia.org#cite_note-32)</sup> They argue that the advantages of using hard AI problems as a means for security are twofold. Either the problem goes unsolved and there remains a reliable method for distinguishing humans from computers, or the problem is solved and a difficult AI problem is resolved along with it.[\[31\]](https://en.wikipedia.org#cite_note-Ahn2003-31)

## Accessibility

CAPTCHAs based on reading text—or other visual-perception tasks—prevent blind or visually impaired users from accessing the protected resource.[\[33\]](https://en.wikipedia.org#cite_note-w3c_inaccessibility-33)<sup>[\[34\]](https://en.wikipedia.org#cite_note-34)</sup> Because CAPTCHAs are designed to be unreadable by machines, common assistive technology tools such as screen readers cannot interpret them. The use of CAPTCHA thus excludes a small percentage of users from using significant subsets of such common Web-based services as PayPal, Gmail, Orkut, Yahoo!, many forum and weblog systems, etc.<sup>[\[35\]](https://en.wikipedia.org#cite_note-35)</sup> In certain jurisdictions, site owners could become targets of litigation if they are using CAPTCHAs that discriminate against certain people with disabilities. For example, a CAPTCHA may make a site incompatible with Section 508 in the United States.

CAPTCHAs do not have to be visual. Any hard artificial intelligence problem, such as speech recognition, can be used as CAPTCHA. Some implementations of CAPTCHAs permit users to opt for an audio CAPTCHA, such as reCAPTCHA, though a 2011 paper demonstrated a technique for defeating the popular schemes at the time.[\[36\]](https://en.wikipedia.org#cite_note-36)

A method of improving CAPTCHA to ease the work with it was proposed by ProtectWebForm and named "Smart CAPTCHA".<sup>[\[37\]](https://en.wikipedia.org#cite_note-37)</sup> Developers are advised to combine CAPTCHA with JavaScript. Since it is hard for most bots to parse and execute JavaScript, a combinatory method which fills the CAPTCHA fields and hides both the image and the field from human eyes was proposed.[\[38\]](https://en.wikipedia.org#cite_note-38)

One alternative method involves displaying to the user a simple mathematical equation and requiring the user to enter the solution as verification. Although these are much easier to defeat using software, they are suitable for scenarios where graphical imagery is not appropriate, and they provide a much higher level of accessibility for blind users than the image-based CAPTCHAs. These are sometimes referred to as MAPTCHAs (M = "mathematical"). However, these may be difficult for users with a cognitive disorder, such as dyscalculia.[\[39\]](https://en.wikipedia.org#cite_note-39)

Challenges such as a logic puzzle, or trivia question can also be used as a CAPTCHA. There is research into their resistance against countermeasures.[\[40\]](https://en.wikipedia.org#cite_note-40)

## Circumvention

Two main ways to bypass CAPTCHA include using cheap human labor to recognize them, and using machine learning to build an automated solver.<sup>[\[41\]](https://en.wikipedia.org#cite_note-41)</sup> According to former Google "click fraud czar" Shuman Ghosemajumder, there are numerous services which solve CAPTCHAs automatically.[\[42\]](https://en.wikipedia.org#cite_note-ai-security-42)

### Machine learning–based attacks

There was not a systematic methodology for designing or evaluating early CAPTCHAs.<sup>[\[30\]](https://en.wikipedia.org#cite_note-bursz-30)</sup> As a result, there were many instances in which CAPTCHAs were of a fixed length and therefore automated tasks could be constructed to successfully make educated guesses about where segmentation should take place. Other early CAPTCHAs contained limited sets of words, which made the test much easier to game<sup>\*[example needed*\]</sup> made the mistake of relying too heavily on background confusion in the image. In each case, algorithms were created that were successfully able to complete the task by exploiting these design flaws. However, light changes to the CAPTCHA could thwart them. Modern CAPTCHAs like reCAPTCHA rely on present variations of characters that are collapsed together, making them hard to segment, and they have warded off automated tasks.[\[43\]](https://en.wikipedia.org#cite_note-bursz2-43)

In October 2013, artificial intelligence company Vicarious claimed that it had developed a generic CAPTCHA-solving algorithm that was able to solve modern CAPTCHAs with character recognition rates of up to 90%.<sup>[\[44\]](https://en.wikipedia.org#cite_note-44)</sup> However, Luis von Ahn, a pioneer of early CAPTCHA and founder of reCAPTCHA, said: "It's hard for me to be impressed since I see these every few months." 50 similar claims to that of Vicarious had been made since 2003.[\[45\]](https://en.wikipedia.org#cite_note-45)

In August 2014 at Usenix WoOT conference, Bursztein et al. presented the first generic CAPTCHA-solving algorithm based on reinforcement learning and demonstrated its efficiency against many popular CAPTCHA schemas.[\[43\]](https://en.wikipedia.org#cite_note-bursz2-43)

In October 2018 at ACM CCS'18 conference, Ye et al. presented a deep learning-based attack that could consistently solve all 11 text captcha schemes used by the top-50 popular websites in 2018. An effective CAPTCHA solver can be trained using as few as 500 real CAPTCHAs.[\[46\]](https://en.wikipedia.org#cite_note-46)

### Human labor

It is possible to subvert CAPTCHAs by relaying them to a sweatshop of human operators who are employed to decode CAPTCHAs. A 2005 paper from a W3C working group said that they could verify hundreds per hour.<sup>[\[33\]](https://en.wikipedia.org#cite_note-w3c_inaccessibility-33)</sup> In 2010, the University of California at San Diego conducted a large scale study of CAPTCHA farms. The retail price for solving one million CAPTCHAs was as low as $1,000.[\[47\]](https://en.wikipedia.org#cite_note-motoyama-47)

Another technique consists of using a script to re-post the target site's CAPTCHA as a CAPTCHA to the attacker's site, which unsuspecting humans visit and solve within a short while for the script to use.[\[48\]](https://en.wikipedia.org#cite_note-48)[\[49\]](https://en.wikipedia.org#cite_note-49)

In 2023, researchers prompted ChatGPT to trick a TaskRabbit worker into solving a CAPTCHA by telling the worker it was not a robot and had impaired vision.[\[50\]](https://en.wikipedia.org#cite_note-50)

### Outsourcing to paid services

There are multiple Internet companies like *2Captcha* and *DeathByCaptcha* that offer human and machine backed CAPTCHA solving services for as low as US$0.50 per 1000 solved CAPTCHAs.<sup>[\[51\]](https://en.wikipedia.org#cite_note-51)</sup> These services offer APIs and libraries that enable users to integrate CAPTCHA circumvention into the tools that CAPTCHAs were designed to block in the first place.[\[52\]](https://en.wikipedia.org#cite_note-52)

### Insecure implementation

Howard Yeend has identified two implementation issues with poorly designed CAPTCHA systems:<sup>[\[53\]](https://en.wikipedia.org#cite_note-53)</sup> reusing the session ID of a known CAPTCHA image, and CAPTCHAs residing on shared servers.

Sometimes, if part of the software generating the CAPTCHA is client-side (the validation is done on a server but the text that the user is required to identify is rendered on the client side), then users can modify the client to display the un-rendered text. Some CAPTCHA systems use MD5 hashes stored client-side, which may leave the CAPTCHA vulnerable to a brute-force attack.[\[54\]](https://en.wikipedia.org#cite_note-54)

## Alternative CAPTCHAs

Some researchers have proposed alternatives including image recognition CAPTCHAs

Chew et al. published their work in the 7th International Information Security Conference, ISC'04, proposing three different versions of image recognition CAPTCHAs, and validating the proposal with user studies. It is suggested that one of the versions, the anomaly CAPTCHA, is best with 100% of human users being able to pass an anomaly CAPTCHA with at least 90% probability in 42 seconds.<sup>[\[55\]](https://en.wikipedia.org#cite_note-55)</sup> Datta et al. published their paper in the ACM Multimedia 2005 Conference, named IMAGINATION (IMAge Generation for INternet AuthenticaTION), proposing a systematic way to image recognition CAPTCHAs. Images are distorted so image recognition approaches cannot recognize them.[\[56\]](https://en.wikipedia.org#cite_note-56)

A team of researchers at Microsoft (Jeremy Elson, John R. Douceur, Jon Howell, and Jared Saul) developed an Animal Species Image Recognition for Restricting Access (ASIRRA), which asked users to distinguish cats from dogs. Microsoft had a beta version of this available for websites to use in 2008.<sup>[\[57\]](https://en.wikipedia.org#cite_note-57)</sup> They said that "Asirra is easy for users; it can be solved by humans 99.6% of the time in under 30 seconds. Anecdotally, users seemed to find the experience of using Asirra much more enjoyable than a text-based CAPTCHA." This solution was described in a 2007 paper to Proceedings of 14th ACM Conference on Computer and Communications Security (CCS).<sup>[\[58\]](https://en.wikipedia.org#cite_note-58)</sup> The service was shut down in October 2014.[\[59\]](https://en.wikipedia.org#cite_note-59)

## Malicious CAPTCHA imitations

False CAPTCHAs are being used to deliver malware. Threat actors take advantage of "verification fatigue" to trick people into copying and executing console commands that download and install malicious code such as spyware in order to steal passwords, mobile wallet details, and other personal information. Such attempted frauds are reported to succeed more often than others.[\[60\]](https://en.wikipedia.org#cite_note-60)[\[61\]](https://en.wikipedia.org#cite_note-61)[\[62\]](https://en.wikipedia.org#cite_note-62)

## See also

## References

1. ↑ "The reCAPTCHA Project – Carnegie Mellon University CyLab". *www.cylab.cmu.edu*. Archived from the original on 27 October 2017. Retrieved 13 January 2017.
2. ↑ von Ahn, Luis; Blum, Manuel; Hopper, Nicholas J.; Langford, John (May 2003). "CAPTCHA: Using Hard AI Problems for Security" (PDF). *Advances in Cryptology—EUROCRYPT 2003*. EUROCRYPT 2003: International Conference on the Theory and Applications of Cryptographic Techniques. Lecture Notes in Computer Science. Vol. 2656. pp. 294–311. doi:10.1007/3-540-39200-9\_18. ISBN 978-3-540-14039-9. Archived (PDF) from the original on 4 May 2019. Retrieved 30 August 2019.
3. ↑ "What is CAPTCHA?". *Google Support*. Google Inc. Archived from the original on 6 August 2020. Retrieved 9 September 2022. CAPTCHA (Completely Automated Public Turing test to tell Computers and Humans Apart) is a \[...\]
4. ↑ Mayumi Takaya; Yusuke Tsuruta; Akihiro Yamamura (30 September 2013). "Reverse Turing Test using Touchscreens and CAPTCHA" (PDF). *Journal of Wireless Mobile Networks, Ubiquitous Computing, and Dependable Applications*. **4** (3): 41–57. doi:10.22667/JOWUA.2013.09.31.041. Archived (PDF) from the original on 22 August 2017.
5. ↑ "What is reCAPTCHA? –?reCAPTCHA Help". *support.google.com*. Archived from the original on 20 July 2023. Retrieved 20 July 2023.
6. ↑ Sulgrove, Jonathan (7 July 2022). "reCAPTCHA: What It Is and Why You Should Use It on Your Website – TSTS". *Twin State Technical Services*. Archived from the original on 10 November 2022. Retrieved 10 November 2022.
7. ↑ "Websites using hCaptcha". *trends.builtwith.com*. Archived from the original on 10 November 2022. Retrieved 10 November 2022.
8. ↑ "Who we are". *www.hcaptcha.com*. Archived from the original on 20 July 2023. Retrieved 20 July 2023. hCaptcha is a service of Intuition Machines.
9. ↑ Meunier, Thibault (13 May 2021). "Humanity wastes about 500 years per day on CAPTCHAs. It's time to end this madness". *Cloudflare blog*. Based on our data, it takes a user on average 32 seconds to complete a CAPTCHA challenge.
10. ↑ Bursztein, Elie; Bethard, Steven; Fabry, Celine; Mitchell, John C.; Jurafsky, Dan (2010). "How Good Are Humans at Solving CAPTCHAs? A Large Scale Evaluation" (PDF). *2010 IEEE Symposium on Security and Privacy*. pp. 399–413. doi:10.1109/SP.2010.31. ISBN 978-1-4244-6894-2. S2CID 14204454. Archived (PDF) from the original on 8 August 2018. Retrieved 30 March 2018.
11. ↑ Stec, Albert (12 June 2022). "What is CAPTCHA and How Does It Work?". *Baeldung on Computer Science*. Archived from the original on 1 November 2022. Retrieved 1 November 2022.
12. ↑ "What is a CAPTCHA?". *Cloudflare*. 1 November 2022. Archived from the original on 27 October 2022. Retrieved 1 November 2022.
13. 1 2 Rodgers, Reece (3 November 2025). "The Curious Case of the Bizarre, Disappearing Captcha". *WIRED*. Archived from the original on 28 February 2026. Retrieved 12 July 2026.
14. ↑ Morreale, F.; Bahmanteymouri, E.; Burmester, B.; et al. (17 May 2023). "The unwitting labourer: extracting humanness in AI training". *AI & Society*. **39** (2024). Springer. 2392. doi:10.1007/s00146-023-01692-3. hdl:2292/64267. Retrieved 12 July 2026.
15. 1 2 "idrive turing patent application". Archived from the original on 15 March 2023. Retrieved 19 May 2017.
16. ↑ "h2g2 – An Explanation of l33t Speak – Edited Entry". *h2g2*. 16 August 2002. Archived from the original on 6 September 2011.
17. ↑ "idrive turing signup page". *Google Drive*. Archived from the original on 15 March 2023. Retrieved 19 May 2017.
18. ↑ Stringham, Edward P. (2015). *Private Governance: creating order in economic and social life*. Oxford University Press. p. 105. ISBN 978-0-19-936516-6. OCLC 5881934034.
19. ↑ Feng, Yunhe; Cao, Qing; Qi, Hairong; Ruoti, Scott (June 2020). "SenCAPTCHA: A Mobile-First CAPTCHA Using Orientation Sensors". *Proceedings of the ACM on Interactive, Mobile, Wearable and Ubiquitous Technologies*. **4** (2). Article 43, pp. 1–26. doi:10.1145/3397312.
20. ↑ Soto, Micah (24 May 2019). "The origin of CAPTCHA and reCAPTCHA".
21. ↑ United States 6195698B1, Mark D. Lillibridge; Krishna Bharat & Martin Abadi et al., published 13 April 1998
22. ↑ "Teaching computers to read: Google acquires reCAPTCHA". *Google Official Blog*. Archived from the original on 31 August 2019. Retrieved 29 October 2018.
23. ↑ Gugliotta, Guy (28 March 2011). "Deciphering Old Texts, One Woozy, Curvy Word at a Time". *The New York Times*. Archived from the original on 17 November 2017. Retrieved 29 October 2018.
24. 1 2 Sivakorn, Suphannee; Polakis, Iasonas; Keromytis, Angelos D. (March 2016). "I am Robot: (Deep) Learning to Break Semantic Image CAPTCHAs". *2016 IEEE European Symposium o

[content truncated; raise max_chars or request the source URL for more]

Sources:
- https://en.wikipedia.org/wiki/Help:IPA/English
- https://en.wikipedia.org/wiki/Help:Pronunciation_respelling_key
- https://en.wikipedia.org/wiki/Challenge-response
- https://en.wikipedia.org/wiki/Turing_test
- https://en.wikipedia.org/wiki/Computing
- https://en.wikipedia.org/wiki/User_interface
- https://en.wikipedia.org/wiki/Spambot
- https://en.wikipedia.org/wiki/Spamming
- https://en.wikipedia.org/wiki/User_(computing)
- https://en.wikipedia.org/wiki/Luis_von_Ahn
- https://en.wikipedia.org/wiki/Manuel_Blum
- https://en.wikipedia.org/wiki/John_Langford_(computer_scientist)
- https://en.wikipedia.org/wiki/Contrived_acronym
- https://en.wikipedia.org/wiki/ReCAPTCHA_v1
- https://en.wikipedia.org/wiki/Reverse_Turing_test
- https://en.wikipedia.org/wiki/Google
- https://en.wikipedia.org/wiki/ReCAPTCHA
- https://en.wikipedia.org/wiki/Cloudflare
- https://en.wikipedia.org/wiki/Stanford_University
- https://en.wikipedia.org/wiki/Denial-of-service_attack
- https://en.wikipedia.org/wiki/IP_address
- https://en.wikipedia.org/wiki/Data_set
- https://en.wikipedia.org/wiki/AI
- https://en.wikipedia.org/wiki/Hacker_culture
- https://en.wikipedia.org/wiki/Internet_forum
- https://en.wikipedia.org/wiki/Leet
- https://en.wikipedia.org/wiki/PayPal
- https://en.wikipedia.org/wiki/Max_Levchin
- https://en.wikipedia.org/wiki/AltaVista
- https://en.wikipedia.org/wiki/The_New_York_Times
- https://en.wikipedia.org/wiki/Google_Books
- https://en.wikipedia.org/wiki/Canvas_fingerprinting
- https://en.wikipedia.org/wiki/GrapheneOS
- https://en.wikipedia.org/wiki/LineageOS
- https://en.wikipedia.org/wiki/Object_recognition_(cognitive_science)#Object_constancy_and_theories_of_object_recognition
- https://en.wikipedia.org/wiki/Image_segmentation
- https://en.wikipedia.org/wiki/AI-complete
- https://en.wikipedia.org/wiki/Blindness
- https://en.wikipedia.org/wiki/Visual_impairment
- https://en.wikipedia.org/wiki/Assistive_technology

[246 source links omitted by the link cap]
