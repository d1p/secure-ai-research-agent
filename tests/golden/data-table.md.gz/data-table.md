# List of countries and dependencies by population - Wikipedia

## List of countries and dependencies by population

Source: https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population

1. India (17.3%)
2. China (17.0%)
3. United States (4.10%)
4. Indonesia (3.50%)
5. Pakistan (2.90%)
6. Nigeria (2.70%)
7. Brazil (2.60%)
8. Bangladesh (2.10%)
9. Russia (1.80%)
10. Other countries (46.0%)

As of 2026, the most populous country in the world is India, followed closely by China, with both exceeding 1.4 billion.

## Method

This list includes sovereign states, inhabited dependent territories and, in some cases, constituent countries of sovereign states, with inclusion within the list being primarily based on the ISO standard ISO 3166-1. For instance, the United Kingdom is considered a single entity, while the constituent countries of the Kingdom of the Netherlands are considered separately. In addition, this list includes certain states with limited recognition not found in ISO 3166-1. Also given in a percentage is each country's population compared with the world population, which the United Nations estimated at 8.232 billion as of 2025.[\[1\]](https://en.wikipedia.org#cite_note-UNFPA-1)

Figures used in this chart are based on the most up-to-date estimates or projections by the national census authority, where available, and are usually rounded off. Where updated national data are not available, figures are based on the estimates or projections for 2024 by the Population Division of the United Nations Department of Economic and Social Affairs.

Because the compiled figures are not collected at the same time in every country, or at the same level of accuracy, the resulting numerical comparisons may create misleading conclusions. Furthermore, the addition of figures from all countries may not equal the world total.

Areas that form integral parts of sovereign states, such as the countries of the United Kingdom, are counted as part of the sovereign states concerned. Not included are other entities that are not sovereign states, such as the European Union,<sup>[\[a\]](https://en.wikipedia.org#cite_note-2)</sup> and independent territories that do not have permanent populations, such as the Chagos Archipelago and various countries' claims to Antarctica.[\[2\]](https://en.wikipedia.org#cite_note-3)

## Sovereign states and dependencies by population

Note: A numbered rank is assigned to the 193 member states of the United Nations, plus the 2 observer states to the United Nations General Assembly. Dependent territories and constituent countries that are parts of sovereign states are not assigned a numbered rank. In addition, sovereign states with limited recognition are also included, but not assigned a numbered rank.

| List of countries and territories by total population |  |  |  |  |  |
|---|---|---|---|---|---|
| Location | Population | % of world | Date | Source (official or from the United Nations) | Notes |
|---|---|---|---|---|---|
|  **World** | 8,232,000,000 | 100% | 13 Jun 2025 | UN projection <sup>[\[1\]](https://en.wikipedia.org#cite_note-UNFPA-1)</sup><sup>[\[3\]](https://en.wikipedia.org#cite_note-auto1-4)</sup> |  |
| India | 1,429,404,000 | 17.3% | 1 Jul 2026 | Official projection <sup>[\[4\]](https://en.wikipedia.org#cite_note-5)</sup> | <sup>[\[b\]](https://en.wikipedia.org#cite_note-6)</sup> |
| China | 1,404,890,000 | 17.0% | 31 Dec 2025 | Official estimate <sup>[\[5\]](https://en.wikipedia.org#cite_note-7)</sup> | <sup>[\[c\]](https://en.wikipedia.org#cite_note-8)</sup> |
| United States | 341,784,857 | 4.1% | 1 Jul 2025 | Official estimate <sup>[\[6\]](https://en.wikipedia.org#cite_note-9)</sup> | <sup>[\[d\]](https://en.wikipedia.org#cite_note-10)</sup> |
| Indonesia | 290,125,073 | 3.5% | 30 Jun 2026 | National annual projection <sup>[\[7\]](https://en.wikipedia.org#cite_note-11)</sup> |  |
| Pakistan | 241,499,431 | 2.9% | 1 Mar 2023 | 2023 census result <sup>[\[8\]](https://en.wikipedia.org#cite_note-12)</sup> | <sup>[\[e\]](https://en.wikipedia.org#cite_note-13)</sup> |
| Nigeria | 223,800,000 | 2.7% | 1 Jul 2023 | Official projection <sup>[\[9\]](https://en.wikipedia.org#cite_note-14)</sup> |  |
| Brazil | 214,211,951 | 2.6% | 1 Jul 2026 | Official estimate <sup>[\[10\]](https://en.wikipedia.org#cite_note-15)</sup> |  |
| Bangladesh | 169,828,911 | 2.1% | 14 Jun 2022 | 2022 census result <sup>[\[11\]](https://en.wikipedia.org#cite_note-16)</sup> | <sup>[\[f\]](https://en.wikipedia.org#cite_note-18)</sup> |
| Russia | 146,028,325 | 1.8% | 1 Jan 2025 | Official estimate <sup>[\[13\]](https://en.wikipedia.org#cite_note-19)</sup> | <sup>[\[g\]](https://en.wikipedia.org#cite_note-20)</sup> |
| Mexico | 131,231,919 | 1.6% | 30 Jun 2026 | National quarterly estimate <sup>[\[14\]](https://en.wikipedia.org#cite_note-21)</sup> |  |
| Japan | 122,690,000 | 1.5% | 1 Oct 2026 | Monthly national estimate <sup>[\[15\]](https://en.wikipedia.org#cite_note-22)</sup> |  |
| Democratic Republic of the Congo | 116,452,162 | 1.4% | 1 Jul 2026 | UN projection <sup>[\[16\]](https://en.wikipedia.org#cite_note-23)</sup> |  |
| Philippines | 114,849,400 | 1.4% | 1 Jul 2026 | Official projection <sup>[\[17\]](https://en.wikipedia.org#cite_note-24)</sup> |  |
| Ethiopia | 111,652,998 | 1.3% | 1 Jul 2025 | National annual projection <sup>[\[18\]](https://en.wikipedia.org#cite_note-25)</sup> |  |
| Egypt | 108,613,296 | 1.3% | 1 Jan 2026 | Official estimate <sup>[\[19\]](https://en.wikipedia.org#cite_note-26)</sup> |  |
| Vietnam | 102,300,000 | 1.2% | 31 Dec 2025 | Official estimate <sup>[\[20\]](https://en.wikipedia.org#cite_note-27)</sup> |  |
| Iran | 87,134,000 | 1.1% | 21 Mar 2026 | Official estimate <sup>[\[21\]](https://en.wikipedia.org#cite_note-28)</sup> |  |
| Turkey | 86,092,168 | 1.0% | 31 Dec 2025 | Official estimate <sup>[\[22\]](https://en.wikipedia.org#cite_note-29)</sup> |  |
| Germany | 83,298,787 | 1.0% | 30 Jun 2026 | National quarterly estimate <sup>[\[23\]](https://en.wikipedia.org#cite_note-30)</sup> |  |
| Thailand | 70,250,751 | 0.8% | 2025 | Preliminary census results <sup>[\[24\]](https://en.wikipedia.org#cite_note-31)</sup> |  |
| Tanzania | 70,038,850 | 0.8% | 1 Jul 2026 | Official projection <sup>[\[25\]](https://en.wikipedia.org#cite_note-32)</sup> | <sup>[\[h\]](https://en.wikipedia.org#cite_note-33)</sup> |
| United Kingdom | 69,487,000 | 0.8% | 30 Jun 2025 | Official estimate <sup>[\[26\]](https://en.wikipedia.org#cite_note-34)</sup> | <sup>[\[i\]](https://en.wikipedia.org#cite_note-35)</sup> |
| France | 69,081,996 | 0.8% | 1 Jan 2026 | Yearly national estimate <sup>[\[27\]](https://en.wikipedia.org#cite_note-36)</sup> | <sup>[\[j\]](https://en.wikipedia.org#cite_note-37)</sup> |
| South Africa | 63,522,380 | 0.8% | 30 Jun 2026 | Official estimate <sup>[\[28\]](https://en.wikipedia.org#cite_note-38)</sup> |  |
| Italy | 58,943,673 | 0.7% | 30 Jun 2026 | Monthly national estimate <sup>[\[29\]](https://en.wikipedia.org#cite_note-39)</sup> |  |
| Kenya | 54,227,015 | 0.7% | 1 Jul 2026 | Official projection <sup>[\[30\]](https://en.wikipedia.org#cite_note-40)</sup> |  |
| Colombia | 53,399,171 | 0.6% | 1 Jan 2026 | Official projection <sup>[\[31\]](https://en.wikipedia.org#cite_note-41)</sup> |  |
| Sudan | 53,282,719 | 0.6% | 1 Jul 2026 | UN projection <sup>[\[32\]](https://en.wikipedia.org#cite_note-auto3-42)</sup> |  |
| Myanmar | 51,375,327 | 0.6% | 15 Oct 2024 | 2024 census result <sup>[\[33\]](https://en.wikipedia.org#cite_note-43)</sup> | <sup>[\[k\]](https://en.wikipedia.org#cite_note-45)</sup> |
| South Korea | 51,088,284 | 0.6% | 31 Jul 2026 | Monthly national estimate <sup>[\[35\]](https://en.wikipedia.org#cite_note-46)</sup> |  |
| Spain | 49,801,559 | 0.6% | 1 Jul 2026 | National quarterly estimate <sup>[\[36\]](https://en.wikipedia.org#cite_note-47)</sup> |  |
| Algeria | 47,400,000 | 0.6% | 1 Jan 2025 | National annual projection <sup>[\[37\]](https://en.wikipedia.org#cite_note-48)</sup> |  |
| Argentina | 46,466,688 | 0.6% | 1 Jul 2026 | National annual projection <sup>[\[38\]](https://en.wikipedia.org#cite_note-renaper1-49)</sup> |  |
| Iraq | 46,118,793 | 0.6% | 21 Nov 2024 | 2024 census result <sup>[\[39\]](https://en.wikipedia.org#cite_note-50)</sup> |  |
| Uganda | 45,905,417 | 0.6% | 10 May 2024 | 2024 census result <sup>[\[40\]](https://en.wikipedia.org#cite_note-51)</sup> |  |
| Afghanistan | 43,844,000 | 0.5% | 1 Jul 2025 | UN projection <sup>[\[41\]](https://en.wikipedia.org#cite_note-UN_pop-52)</sup><sup>[\[42\]](https://en.wikipedia.org#cite_note-53)</sup> (see note) | <sup>[\[l\]](https://en.wikipedia.org#cite_note-60)</sup> |
| Canada | 41,798,407 | 0.5% | 1 Jul 2026 | National quarterly estimate <sup>[\[49\]](https://en.wikipedia.org#cite_note-61)</sup> |  |
| Uzbekistan | 39,047,321 | 0.5% | 15 Jan 2026 | 2026 census result <sup>[\[50\]](https://en.wikipedia.org#cite_note-Xinhua-62)</sup> |  |
| Angola | 38,778,554 | 0.5% | 1 Jan 2026 | National estimate <sup>[\[51\]](https://en.wikipedia.org#cite_note-63)</sup> |  |
| Morocco | 37,254,695 | 0.5% | 1 Jul 2026 | National annual projection <sup>[\[52\]](https://en.wikipedia.org#cite_note-64)</sup> | <sup>[\[m\]](https://en.wikipedia.org#cite_note-65)</sup> |
| Poland | 37,232,000 | 0.4% | 31 Jul 2026 | Monthly national estimate <sup>[\[53\]](https://en.wikipedia.org#cite_note-66)</sup> |  |
| Saudi Arabia | 35,300,280 | 0.4% | 1 Jul 2024 | Official estimate <sup>[\[54\]](https://en.wikipedia.org#cite_note-67)</sup> |  |
| Mozambique | 34,958,973 | 0.4% | 1 Jul 2026 | National annual projection <sup>[\[55\]](https://en.wikipedia.org#cite_note-68)</sup> |  |
| Malaysia | 34,389,400 | 0.4% | 30 Jun 2026 | National quarterly estimate <sup>[\[56\]](https://en.wikipedia.org#cite_note-69)</sup> |  |
| Ghana | 34,378,768 | 0.4% | 1 Jul 2026 | National annual projection <sup>[\[57\]](https://en.wikipedia.org#cite_note-70)</sup> |  |
| Peru | 34,157,732 | 0.4% | 4 Aug 2025 | Census 2025 <sup>[\[58\]](https://en.wikipedia.org#cite_note-71)</sup> |  |
| Ivory Coast | 33,293,101 | 0.4% | 1 Jul 2026 | National annual projection <sup>[\[59\]](https://en.wikipedia.org#cite_note-72)</sup> |  |
| Yemen | 32,684,503 | 0.4% | 1 Jul 2023 | Official estimate <sup>[\[60\]](https://en.wikipedia.org#cite_note-73)</sup> |  |
| Madagascar | 32,658,977 | 0.4% | 1 Jul 2026 | National annual projection <sup>[\[61\]](https://en.wikipedia.org#cite_note-74)</sup> |  |
| Nepal | 30,034,040 | 0.4% | 1 Jul 2026 | National annual projection <sup>[\[62\]](https://en.wikipedia.org#cite_note-75)</sup> |  |
| Cameroon | 29,442,327 | 0.4% | 1 Jul 2025 | National annual projection <sup>[\[63\]](https://en.wikipedia.org#cite_note-76)</sup> |  |
| Ukraine | 28,700,000 | 0.3% | 1 Sep 2025 | State migration service <sup>[\[64\]](https://en.wikipedia.org#cite_note-77)</sup> | <sup>[\[n\]](https://en.wikipedia.org#cite_note-78)</sup> |
| Venezuela | 28,633,711 | 0.3% | 1 Jul 2026 | UN projection <sup>[\[65\]](https://en.wikipedia.org#cite_note-79)</sup> |  |
| Australia | 27,921,150 | 0.3% | 31 Mar 2026 | Official projection <sup>[\[66\]](https://en.wikipedia.org#cite_note-80)</sup> | <sup>[\[o\]](https://en.wikipedia.org#cite_note-81)</sup> |
| Niger | 27,522,750 | 0.3% | 1 Jul 2025 | National annual projection <sup>[\[67\]](https://en.wikipedia.org#cite_note-82)</sup> |  |
| Syria | 26,472,497 | 0.3% | 1 Jul 2026 | Monthly estimate <sup>[\[68\]](https://en.wikipedia.org#cite_note-83)</sup> |  |
| North Korea | 25,950,000 | 0.3% | 1 Jul 2024 | National annual projection <sup>[\[69\]](https://en.wikipedia.org#cite_note-84)</sup> |  |
| Burkina Faso | 24,736,828 | 0.3% | 1 Jul 2026 | Official projection <sup>[\[70\]](https://en.wikipedia.org#cite_note-85)</sup> |  |
| Mali | 23,929,000 | 0.3% | 1 Jul 2024 | Official projection <sup>[\[71\]](https://en.wikipedia.org#cite_note-86)</sup> |  |
| Taiwan | 23,213,251 | 0.3% | 30 Sep 2026 | Official estimate <sup>[\[72\]](https://en.wikipedia.org#cite_note-87)</sup> | <sup>[\[p\]](https://en.wikipedia.org#cite_note-88)</sup> |
| Zambia | 23,003,214 | 0.3% | 1 Jul 2026 | Official estimate <sup>[\[73\]](https://en.wikipedia.org#cite_note-89)</sup> |  |
| Sri Lanka | 21,778,000 | 0.3% | 1 Jul 2026 | Official estimate <sup>[\[74\]](https://en.wikipedia.org#cite_note-90)</sup> |  |
| Malawi | 21,201,635 | 0.3% | 1 Jul 2026 | National annual projection <sup>[\[75\]](https://en.wikipedia.org#cite_note-91)</sup> |  |
| Kazakhstan | 20,618,796 | 0.2% | 1 Sep 2026 | Official estimate <sup>[\[76\]](https://en.wikipedia.org#cite_note-92)</sup> |  |
| Somalia | 20,305,907 | 0.2% | 1 Jul 2026 | UN projection <sup>[\[32\]](https://en.wikipedia.org#cite_note-auto3-42)</sup> | <sup>[\[q\]](https://en.wikipedia.org#cite_note-93)</sup> |
| Chile | 20,150,948 | 0.2% | 30 Jun 2026 | National annual projection <sup>[\[77\]](https://en.wikipedia.org#cite_note-94)</sup> |  |
| Chad | 20,031,602 | 0.2% | 1 Jul 2026 | National annual projection <sup>[\[78\]](https://en.wikipedia.org#cite_note-95)</sup> |  |
| Senegal | 19,575,061 | 0.2% | 1 Jul 2026 | National annual projection <sup>[\[79\]](https://en.wikipedia.org#cite_note-96)</sup> |  |
| Romania | 19,041,322 | 0.2% | 1 Jan 2026 | Official estimate <sup>[\[80\]](https://en.wikipedia.org#cite_note-97)</sup> |  |
| Guatemala | 18,312,373 | 0.2% | 1 Jul 2026 | National annual projection <sup>[\[81\]](https://en.wikipedia.org#cite_note-98)</sup> |  |
| Ecuador | 18,243,816 | 0.2% | 1 Jul 2026 | National annual projection <sup>[\[82\]](https://en.wikipedia.org#cite_note-99)</sup> |  |
| Netherlands | 18,171,612 | 0.2% | 31 Aug 2026 | Official estimate <sup>[\[83\]](https://en.wikipedia.org#cite_note-100)</sup> | <sup>[\[r\]](https://en.wikipedia.org#cite_note-101)</sup> |
| Cambodia | 17,816,143 | 0.2% | 1 Jul 2026 | Official projection <sup>[\[84\]](https://en.wikipedia.org#cite_note-102)</sup> |  |
| Guinea | 17,521,167 | 0.2% | 1 Jul 2025 | Census July 2025 <sup>[\[85\]](https://en.wikipedia.org#cite_note-103)</sup> |  |
| Zimbabwe | 16,175,966 | 0.2% | 1 Jul 2026 | Official projection <sup>[\[86\]](https://en.wikipedia.org#cite_note-104)</sup> |  |
| South Sudan | 15,786,898 | 0.2% | 1 Jul 2025 | National annual projection <sup>[\[87\]](https://en.wikipedia.org#cite_note-105)</sup> |  |
| Rwanda | 14,418,145 | 0.2% | 1 Jul 2026 | National annual projection <sup>[\[88\]](https://en.wikipedia.org#cite_note-106)</sup> |  |
| Benin | 13,551,992 | 0.2% | 1 Jul 2026 | National annual projection <sup>[\[89\]](https://en.wikipedia.org#cite_note-107)</sup> |  |
| Burundi | 12,332,788 | 0.1% | 16 Aug 2024 | Preliminary census result <sup>[\[90\]](https://en.wikipedia.org#cite_note-108)</sup> |  |
| Tunisia | 11,992,843 | 0.1% | 1 Jan 2026 | National estimate <sup>[\[91\]](https://en.wikipedia.org#cite_note-109)</sup> |  |
| Belgium | 11,944,011 | 0.1% | 1 Aug 2026 | Official estimate <sup>[\[92\]](https://en.wikipedia.org#cite_note-110)</sup> |  |
| Jordan | 11,937,000 | 0.1% | 31 Dec 2025 | National estimate <sup>[\[93\]](https://en.wikipedia.org#cite_note-111)</sup> |  |
| Haiti | 11,867,032 | 0.1% | 1 Jul 2024 | National annual projection <sup>[\[94\]](https://en.wikipedia.org#cite_note-112)</sup> |  |
| Portugal | 11,424,031 | 0.1% | 31 Dec 2025 | Official estimate <sup>[\[95\]](https://en.wikipedia.org#cite_note-113)</sup> |  |
| Bolivia | 11,365,333 | 0.1% | 23 Mar 2024 | 2024 census result <sup>[\[96\]](https://en.wikipedia.org#cite_note-114)</sup> |  |
| United Arab Emirates | 11,294,243 | 0.1% | 31 Dec 2024 | Official estimate <sup>[\[97\]](https://en.wikipedia.org#cite_note-115)</sup> |  |
| Czech Republic | 10,903,655 | 0.1% | 30 Jun 2026 | Official estimate <sup>[\[98\]](https://en.wikipedia.org#cite_note-116)</sup> |  |
| Dominican Republic | 10,771,504 | 0.1% | 10 Nov 2022 | 2022 census result <sup>[\[99\]](https://en.wikipedia.org#cite_note-117)</sup> |  |
| Tajikistan | 10,721,000 | 0.1% | 1 Jan 2026 | Official estimate <sup>[\[100\]](https://en.wikipedia.org#cite_note-118)</sup> |  |
| Sweden | 10,621,103 | 0.1% | 31 Aug 2026 | Monthly national estimate <sup>[\[101\]](https://en.wikipedia.org#cite_note-119)</sup> |  |
| Greece | 10,372,335 | 0.1% | 1 Jan 2025 | Official estimate <sup>[\[102\]](https://en.wikipedia.org#cite_note-120)</sup> |  |
| Israel | 10,305,000 | 0.1% | 31 Aug 2026 | Monthly national estimate <sup>[\[103\]](https://en.wikipedia.org#cite_note-121)</sup> | <sup>[\[s\]](https://en.wikipedia.org#cite_note-122)</sup> |
| Azerbaijan | 10,273,450 | 0.1% | 1 Jul 2026 | Monthly national estimate <sup>[\[104\]](https://en.wikipedia.org#cite_note-123)</sup> |  |
| Honduras | 10,186,738 | 0.1% | 1 Jul 2026 | National annual projection <sup>[\[105\]](https://en.wikipedia.org#cite_note-124)</sup> |  |
| Papua New Guinea | 10,185,363 | 0.1% | 16 Jun 2024 | 2024 census result <sup>[\[106\]](https://en.wikipedia.org#cite_note-125)</sup> |  |
| Hungary | 9,488,428 | 0.1% | 1 Jan 2026 | Official estimate <sup>[\[107\]](https://en.wikipedia.org#cite_note-126)</sup> |  |
| Cuba | 9,434,593 | 0.1% | 31 Dec 2025 | Official estimate <sup>[\[108\]](https://en.wikipedia.org#cite_note-127)</sup> |  |
| Sierra Leone | 9,270,700 | 0.1% | 1 Jul 2026 | National annual projection <sup>[\[109\]](https://en.wikipedia.org#cite_note-128)</sup> |  |
| Austria | 9,217,573 | 0.1% | 1 Jul 2026 | National quarterly estimate <sup>[\[110\]](https://en.wikipedia.org#cite_note-129)</sup> |  |
| Switzerland | 9,154,896 | 0.1% | 30 Jun 2026 | National quarterly estimate <sup>[\[111\]](https://en.wikipedia.org#cite_note-130)</sup> |  |
| Belarus | 9,056,080 | 0.1% | 1 Jan 2026 | Official estimate <sup>[\[112\]](https://en.wikipedia.org#cite_note-131)</sup> |  |
| Togo | 8,095,498 | 0.10% | 8 Nov 2022 | 2022 census result <sup>[\[113\]](https://en.wikipedia.org#cite_note-132)</sup> |  |
| Laos | 7,745,000 | 0.09% | 1 Jul 2025 | National annual projection <sup>[\[114\]](https://en.wikipedia.org#cite_note-133)</sup> |  |
| Libya | 7,539,852 | 0.09% | 1 Jul 2026 | UN projection <sup>[\[115\]](https://en.wikipedia.org#cite_note-auto2-134)</sup> |  |
| Hong Kong (China) | 7,518,300 | 0.09% | 30 Jun 2026 | National estimate <sup>[\[116\]](https://en.wikipedia.org#cite_note-135)</sup> |  |
| Kyrgyzstan | 7,404,300 | 0.09% | 1 Jan 2026 | Monthly national estimate <sup>[\[117\]](https://en.wikipedia.org#cite_note-136)</sup> |  |
| Turkmenistan | 7,057,841 | 0.09% | 17 Dec 2022 | 2022 census result <sup>[\[118\]](https://en.wikipedia.org#cite_note-137)</sup> |  |
| Nicaragua | 6,874,748 | 0.08% | 30 Jun 2024 | Official estimate <sup>[\[119\]](https://en.wikipedia.org#cite_note-138)</sup> |  |
| Serbia | 6,532,019 | 0.08% | 1 Jan 2026 | Official estimate <sup>[\[120\]](https://en.wikipedia.org#cite_note-139)</sup> | <sup>[\[t\]](https://en.wikipedia.org#cite_note-140)</sup> |
| Central African Republic | 6,470,307 | 0.08% | 1 Jul 2024 | National annual projection <sup>[\[121\]](https://en.wikipedia.org#cite_note-141)</sup> |  |
| Bulgaria | 6,423,207 | 0.08% | 31 Dec 2025 | Official estimate <sup>[\[122\]](https://en.wikipedia.org#cite_note-142)</sup> |  |
| Singapore | 6,208,500 | 0.07% | 30 Jun 2026 | National annual projection <sup>[\[123\]](https://en.wikipedia.org#cite_note-143)</sup> |  |
| Republic of the Congo | 6,142,180 | 0.07% | 17 May 2023 | 2023 census result <sup>[\[124\]](https://en.wikipedia.org#cite_note-144)</sup> |  |
| Paraguay | 6,109,644 | 0.07% | 9 Nov 2022 | 2022 census result <sup>[\[125\]](https://en.wikipedia.org#cite_note-145)</sup> |  |
| Denmark | 6,038,638 | 0.07% | 1 Sep 2026 | Monthly national estimate <sup>[\[126\]](https://en.wikipedia.org#cite_note-146)</sup> | <sup>[\[u\]](https://en.wikipedia.org#cite_note-147)</sup> |
| El Salvador | 6,029,976 | 0.07% | 2 May 2024 | 2024 census result <sup>[\[127\]](https://en.wikipedia.org#cite_note-148)</sup> |  |
| Lebanon | 5,895,466 | 0.07% | 2026 | Official estimate <sup>[\[128\]](https://en.wikipedia.org#cite_note-149)</sup> |  |
| Finland | 5,659,324 | 0.07% | 31 Aug 2026 | Monthly national estimate <sup>[\[129\]](https://en.wikipedia.org#cite_note-pxnet2.stat.fi-150)</sup> | <sup>[\[v\]](https://en.wikipedia.org#cite_note-151)</sup> |
| Norway | 5,636,904 | 0.07% | 30 Jun 2026 | National quarterly estimate <sup>[\[130\]](https://en.wikipedia.org#cite_note-152)</sup> | <sup>[\[w\]](https://en.wikipedia.org#cite_note-153)</sup> |
| Palestine | 5,557,096 | 0.07% | 31 Dec 2025 | National annual projection <sup>[\[131\]](https://en.wikipedia.org#cite_note-154)</sup> | <sup>[\[x\]](https://en.wikipedia.org#cite_note-155)</sup> |
| Ireland | 5,525,600 | 0.07% | 1 Apr 2026 | National estimate <sup>[\[132\]](https://en.wikipedia.org#cite_note-156)</sup> |  |
| Oman | 5,454,352 | 0.07% | 30 Sep 2026 | Monthly national estimate <sup>[\[133\]](https://en.wikipedia.org#cite_note-157)</sup> |  |
| Slovakia | 5,403,009 | 0.07% | 30 Jun 2026 | National quarterly estimate <sup>[\[134\]](https://en.wikipedia.org#cite_note-158)</sup> |  |
| New Zealand | 5,357,300 | 0.06% | 30 Jun 2026 | National quarterly estimate <sup>[\[135\]](https://en.wikipedia.org#cite_note-159)</sup> | <sup>[\[y\]](https://en.wikipedia.org#cite_note-160)</sup> |
| Liberia | 5,248,621 | 0.06% | 10 Nov 2022 | 2022 census result <sup>[\[136\]](https://en.wikipedia.org#cite_note-161)</sup> |  |
| Costa Rica | 5,217,296 | 0.06% | 30 Jun 2026 | National annual projection <sup>[\[137\]](https://en.wikipedia.org#cite_note-162)</sup> |  |
| Mauritania | 4,927,532 | 0.06% | 25 Dec 2023 | 2023 census result <sup>[\[138\]](https://en.wikipedia.org#cite_note-163)</sup> |  |
| Kuwait | 4,881,254 |

[content truncated; raise max_chars or request the source URL for more]

Sources:
- https://en.wikipedia.org/wiki/Demographics_of_India
- https://en.wikipedia.org/wiki/Demographics_of_China
- https://en.wikipedia.org/wiki/Demographics_of_the_United_States
- https://en.wikipedia.org/wiki/Demographics_of_Indonesia
- https://en.wikipedia.org/wiki/Demographics_of_Pakistan
- https://en.wikipedia.org/wiki/Demographics_of_Nigeria
- https://en.wikipedia.org/wiki/Demographics_of_Brazil
- https://en.wikipedia.org/wiki/Demographics_of_Bangladesh
- https://en.wikipedia.org/wiki/Demographics_of_Russia
- https://en.wikipedia.org/wiki/India
- https://en.wikipedia.org/wiki/China
- https://en.wikipedia.org/wiki/Sovereign_state
- https://en.wikipedia.org/wiki/Dependent_territory
- https://en.wikipedia.org/wiki/International_Organization_for_Standardization
- https://en.wikipedia.org/wiki/ISO_3166-1
- https://en.wikipedia.org/wiki/United_Kingdom
- https://en.wikipedia.org/wiki/Kingdom_of_the_Netherlands
- https://en.wikipedia.org/wiki/List_of_states_with_limited_recognition
- https://en.wikipedia.org/wiki/World_population
- https://en.wikipedia.org/wiki/United_Nations
- https://en.wikipedia.org/wiki/Population_projection
- https://en.wikipedia.org/wiki/Census
- https://en.wikipedia.org/wiki/United_Nations_Department_of_Economic_and_Social_Affairs
- https://en.wikipedia.org/wiki/Countries_of_the_United_Kingdom
- https://en.wikipedia.org/wiki/European_Union
- https://en.wikipedia.org/wiki/Chagos_Archipelago
- https://en.wikipedia.org/wiki/Territorial_claims_in_Antarctica
- https://en.wikipedia.org/wiki/Antarctica
- https://en.wikipedia.org/wiki/Member_states_of_the_United_Nations
- https://en.wikipedia.org/wiki/United_Nations_General_Assembly_observers#Current_non-member_observers
- https://en.wikipedia.org/wiki/Demographics_of_Mexico
- https://en.wikipedia.org/wiki/Demographics_of_Japan
- https://en.wikipedia.org/wiki/Demographics_of_the_Democratic_Republic_of_the_Congo
- https://en.wikipedia.org/wiki/Demographics_of_the_Philippines
- https://en.wikipedia.org/wiki/Demographics_of_Ethiopia
- https://en.wikipedia.org/wiki/Demographics_of_Egypt
- https://en.wikipedia.org/wiki/Demographics_of_Vietnam
- https://en.wikipedia.org/wiki/Demographics_of_Iran
- https://en.wikipedia.org/wiki/Demographics_of_Turkey
- https://en.wikipedia.org/wiki/Demographics_of_Germany

[991 source links omitted by the link cap]
