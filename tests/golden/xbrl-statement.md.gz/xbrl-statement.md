# xbrl-statement

## Consolidated Statements of Operations

> Synthetic table fixture

Source: https://example.com/xbrl-statement

| Metric | 2026 | 2025 |
| --- | --- | --- |
| Revenue | 804,905 | 499,627 |
| Operating income | 231,716 | 89,297 |
| Net income | 252,848 | 89,297 |

[table mode: non-table context omitted; use reader mode for narrative]
