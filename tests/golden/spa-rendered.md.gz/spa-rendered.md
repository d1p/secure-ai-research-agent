## Widget documentation

Source: https://example.com/spa-rendered

Widget is a client-side library for composing dashboards.

## Install

`npm install widget`

## Configuration

| Option | Default |
|---|---|
| theme | auto |
| refreshSeconds | 30 |

The default refresh interval is 30 seconds.
