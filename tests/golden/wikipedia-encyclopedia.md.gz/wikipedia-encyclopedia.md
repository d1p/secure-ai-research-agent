# Reddit - Wikipedia

## Reddit

Source: https://en.wikipedia.org/wiki/Reddit

| Reddit |  |
|---|---|
| Company type | Public |
|---|---|
| Website type | Social news website |
| Available in | Multilingual<sup>[\[notes 1\]](https://en.wikipedia.org#cite_note-1)</sup><sup>[\[1\]](https://en.wikipedia.org#cite_note-2)</sup> |
| Traded as | NYSE: RDDT (Class A) Russell 1000 component S&P 500 component |
| Founded | June 23, 2005 <sup>[\[2\]](https://en.wikipedia.org#cite_note-3)</sup> |
| Headquarters | San Francisco, California, U.S. |
| No. of locations | 5 |
| Area served | Worldwide (except China and North Korea) |
| Owners | Advance Publications (30%)<sup>[\[3\]](https://en.wikipedia.org#cite_note-U.S._Securities_and_Exchange_Commission-2024-4)</sup> Tencent (11%)<sup>[\[3\]](https://en.wikipedia.org#cite_note-U.S._Securities_and_Exchange_Commission-2024-4)</sup> Sam Altman (9%)<sup>[\[3\]](https://en.wikipedia.org#cite_note-U.S._Securities_and_Exchange_Commission-2024-4)</sup> |
| Founders |  |
| Key people | Steve Huffman (CEO) Jen Wong (COO) Drew Vollero (CFO) Christopher Slowe (CTO) Paul Cappuccio (CLO) |
| Industry |  |
| Revenue | US$2.20 billion (2025) |
| Operating income | US$442 million (2025) |
| Net income | US$530 million (2025) |
| Total assets | US$3.24 billion (2025) |
| Total equity | US$2.93 billion (2025) |
| Employees | 2,555 (2025) |
| Parent | Reddit, Inc. |
| Website | reddit.com (official) redditinc.com (corporate) |
| Advertising | Banner ads and promoted links |
| Commercial | Yes |
| Registration | Optional <sup>[\[notes 2\]](https://en.wikipedia.org#cite_note-5)</sup> |
| Users | 121.4 million DAU (2025) |
| Content license | Proprietary |
| Written in |  |
| <sup>[\[5\]](https://en.wikipedia.org#cite_note-10K-8)</sup> |  |

**Reddit** (/ˈrɛdɪt/ ⓘ*RED-it*, stylized **reddit**) is a proprietary American social news website, news aggregator, forum and social media platform. Registered users (commonly referred to as "redditors") submit content to the site such as links, text posts, images, and videos, which are then voted up or down ("upvoted" or "downvoted") by other members. Posts are organized by subject into user-created boards called "subreddits". Submissions with more upvotes appear towards the top of their subreddit and, if they receive enough upvotes, ultimately on the site's front page. Reddit administrators moderate the communities. Moderation is also conducted by subreddit-specific moderators, who are unpaid volunteers.<sup>[\[6\]](https://en.wikipedia.org#cite_note-Ohlheiser-2016-9)</sup> It is operated by **Reddit, Inc.**, based in San Francisco.[\[7\]](https://en.wikipedia.org#cite_note-Similarweb-2024-10)[\[8\]](https://en.wikipedia.org#cite_note-11)

Reddit is one of the most-visited websites. Approximately 10% of the company's revenue comes from licensing deals with Google and OpenAI, expiring in 2027, to license data to train models for artificial intelligence.<sup>[\[9\]](https://en.wikipedia.org#cite_note-12)</sup> The company's remaining revenue comes from internet advertising; a small portion comes from products sold directly to users.

Reddit was founded by University of Virginia roommates Steve Huffman and Alexis Ohanian in June 2005, who were joined by Aaron Swartz that November. Condé Nast Publications acquired the site in October 2006. In 2011, Reddit became an independent subsidiary of Condé Nast's parent company, Advance Publications.[\[10\]](https://en.wikipedia.org#cite_note-13)

Reddit has been noted for its role in political activism, particularly in the United States, with notable left-wing and anti-theist subcultures on the website.<sup>[\[11\]](https://en.wikipedia.org#cite_note-Lopez-2015-14)</sup> It has received praise for many of its features, such as the ability to create several subreddits for niche communities.[\[12\]](https://en.wikipedia.org#cite_note-Madrigal-2014-15)<sup>[\[13\]](https://en.wikipedia.org#cite_note-Renfro-2016-16)</sup> It has been criticized for the spread of misinformation and its voting system which can encourage online echo chambers.[\[14\]](https://en.wikipedia.org#cite_note-Senator_Ben_Ray_Luján-2021-17)

## History

### Early history

The idea and initial development of Reddit originated with college roommates Steve Huffman and Alexis Ohanian in 2005, who attended a lecture by programmer-entrepreneur Paul Graham in Boston during their spring break from University of Virginia.[\[15\]](https://en.wikipedia.org#cite_note-Hempel-2015-18)[\[16\]](https://en.wikipedia.org#cite_note-Fink-2015-19)<sup>[\[17\]](https://en.wikipedia.org#cite_note-20)</sup> After speaking with Huffman and Ohanian following the lecture, Graham invited the two to apply to his startup incubator Y Combinator.<sup>[\[15\]](https://en.wikipedia.org#cite_note-Hempel-2015-18)</sup> Their initial idea, My Mobile Menu, was unsuccessful,[\[18\]](https://en.wikipedia.org#cite_note-21)<sup>[\[19\]](https://en.wikipedia.org#cite_note-Live_Episode-2017-22)</sup> and was intended to allow users to order food by SMS text messaging.[\[15\]](https://en.wikipedia.org#cite_note-Hempel-2015-18)<sup>[\[16\]](https://en.wikipedia.org#cite_note-Fink-2015-19)</sup> During a brainstorming session to pitch another startup, the idea was created for what Graham called the "front page of the Internet".<sup>[\[19\]](https://en.wikipedia.org#cite_note-Live_Episode-2017-22)</sup> For that idea, Huffman and Ohanian were accepted in Y Combinator's first class.[\[15\]](https://en.wikipedia.org#cite_note-Hempel-2015-18)<sup>[\[16\]](https://en.wikipedia.org#cite_note-Fink-2015-19)</sup> Supported by the funding from Y Combinator,<sup>[\[20\]](https://en.wikipedia.org#cite_note-23)</sup> Huffman coded the site in Common Lisp<sup>[\[21\]](https://en.wikipedia.org#cite_note-24)</sup> and together with Ohanian launched Reddit in June 2005.[\[22\]](https://en.wikipedia.org#cite_note-25)<sup>[\[23\]](https://en.wikipedia.org#cite_note-26)</sup> Embarrassed by an empty-looking site, the founders created hundreds of fake users for their posts to make it look more populated.[\[24\]](https://en.wikipedia.org#cite_note-27)

The team expanded to include Christopher Slowe in November 2005. Between November 2005 and January 2006, Reddit merged with Aaron Swartz's company Infogami, and Swartz became an equal owner of the resulting parent company, Not A Bug.[\[25\]](https://en.wikipedia.org#cite_note-28)<sup>[\[26\]](https://en.wikipedia.org#cite_note-29)</sup> Swartz then helped rewrite the software running Reddit using web.py, a web framework he developed. The passage from Aaron Swartz's blog post "Rewriting Reddit"<sup>[\[27\]](https://en.wikipedia.org#cite_note-Rewriting_Reddit-30)</sup> reveals that the switch from Lisp to Python, specifically using the web.py framework developed by Swartz, was driven by a desire for simplicity, maintainability, and performance. Despite facing skepticism and critique from the Lisp community, the change was justified by the efficiency and clarity Python provided for the project. This initiative not only influenced the technical evolution of Reddit but also contributed to the broader web development community by inspiring other frameworks and remaining a significant part of Reddit's history.<sup>[\[27\]](https://en.wikipedia.org#cite_note-Rewriting_Reddit-30)</sup> In 2011, Ohanian claimed that rather than Swartz being a co-founder, the correct description would be that Swartz's company was acquired by Reddit six months after the website was founded.[\[28\]](https://en.wikipedia.org#cite_note-31)

Huffman and Ohanian sold Reddit to Condé Nast Publications, owner of *Wired*, in October 2006 for a reported $10 million to $20 million[\[15\]](https://en.wikipedia.org#cite_note-Hempel-2015-18)<sup>[\[29\]](https://en.wikipedia.org#cite_note-Arrington-2006-32)</sup> and the team moved to San Francisco.<sup>[\[29\]](https://en.wikipedia.org#cite_note-Arrington-2006-32)</sup> In November 2006, Swartz posted to his blog, complaining about the new corporate environment, criticizing its level of productivity.<sup>[\[30\]](https://en.wikipedia.org#cite_note-33)</sup> In January 2007, Swartz was fired for undisclosed reasons.[\[31\]](https://en.wikipedia.org#cite_note-34)

Huffman and Ohanian left Reddit in 2009.<sup>[\[32\]](https://en.wikipedia.org#cite_note-35)</sup> Huffman went on to co-found Hipmunk with Adam Goldstein, and later recruited Ohanian<sup>[\[33\]](https://en.wikipedia.org#cite_note-36)</sup> and Slowe to the new company.<sup>[\[34\]](https://en.wikipedia.org#cite_note-37)</sup> After Huffman and Ohanian left Reddit, Erik Martin, who joined the company as a community manager in 2008 and later became general manager in 2011, played a role in Reddit's growth.[\[35\]](https://en.wikipedia.org#cite_note-38)*VentureBeat* noted that Martin was "responsible for keeping the site going" under Condé Nast's ownership.[\[36\]](https://en.wikipedia.org#cite_note-39)

Yishan Wong joined Reddit as CEO in 2012.<sup>[\[37\]](https://en.wikipedia.org#cite_note-40)</sup> Wong resigned from Reddit in 2014, citing disagreements about his proposal to move the company's offices from San Francisco to nearby Daly City, but also the "stressful and draining" nature of the position.[\[38\]](https://en.wikipedia.org#cite_note-41)<sup>[\[39\]](https://en.wikipedia.org#cite_note-Rushe-2014-42)</sup> Ohanian credited Wong with the company's newfound success as its user base grew from 35 million to 174 million.<sup>[\[39\]](https://en.wikipedia.org#cite_note-Rushe-2014-42)</sup> Wong oversaw the company as it raised $50 million in funding and spun off as an independent company.<sup>[\[40\]](https://en.wikipedia.org#cite_note-Loizos-2017-43)</sup> Also during this time, Reddit began accepting the digital currency Bitcoin for its Reddit Gold subscription service through a partnership with bitcoin payment processor Coinbase in February 2013.[\[41\]](https://en.wikipedia.org#cite_note-44)Ellen Pao replaced Wong as interim CEO in 2014 and resigned in 2015 amid a user revolt over the firing of a popular Reddit employee.<sup>[\[42\]](https://en.wikipedia.org#cite_note-45)</sup> During her tenure, Reddit initiated an anti-harassment policy,<sup>[\[43\]](https://en.wikipedia.org#cite_note-46)</sup> banned involuntary sexualization, and banned several forums that focused on bigoted content or harassment of individuals.[\[44\]](https://en.wikipedia.org#cite_note-47)

### Ohanian and Huffman return

After five years away from the company, Ohanian and Huffman returned to leadership roles: Ohanian became the full-time executive chairman in November 2014 following Wong's resignation, while Pao's departure in July 2015, led to Huffman's return as the company's chief executive.[\[45\]](https://en.wikipedia.org#cite_note-48)[\[46\]](https://en.wikipedia.org#cite_note-49)iOS and Android apps, improved Reddit's mobile website, and created A/B testing infrastructure.<sup>[\[15\]](https://en.wikipedia.org#cite_note-Hempel-2015-18)</sup> The company launched a major redesign of its website in April 2018.<sup>[\[47\]](https://en.wikipedia.org#cite_note-Pardes-2018b-50)</sup> Huffman said new users were turned off from Reddit because it had looked like a "dystopian Craigslist".<sup>[\[47\]](https://en.wikipedia.org#cite_note-Pardes-2018b-50)</sup> Reddit also instituted several technological improvements,<sup>[\[48\]](https://en.wikipedia.org#cite_note-Lagorio-Chafkin-2018-51)</sup> such as a new tool that allows users to hide posts, comments, and private messages from selected redditors in an attempt to curb online harassment,<sup>[\[49\]](https://en.wikipedia.org#cite_note-52)</sup> and new content guidelines. These new content guidelines were aimed at banning content inciting violence and quarantining offensive material.[\[15\]](https://en.wikipedia.org#cite_note-Hempel-2015-18)<sup>[\[48\]](https://en.wikipedia.org#cite_note-Lagorio-Chafkin-2018-51)</sup> Slowe, the company's first employee, rejoined Reddit in 2017 as chief technology officer.[\[50\]](https://en.wikipedia.org#cite_note-Matney-2017-53)

Ohanian resigned as a member of the board in June 2020, in response to the George Floyd protests and requested to be replaced "by a Black candidate".[\[51\]](https://en.wikipedia.org#cite_note-54)Michael Seibel, then-CEO of Y Combinator, was subsequently named to the board.[\[52\]](https://en.wikipedia.org#cite_note-55)

In March 2021, Reddit appointed Drew Vollero, who had worked at Snapchat's parent company, Snap Inc., as its first chief financial officer (CFO) weeks after Reddit's r/wallstreetbets gained popularity during the GameStop short squeeze.[\[53\]](https://en.wikipedia.org#cite_note-56)

### Funding and initial public offering

As of August 2021, Reddit was valued at more than $10 billion following a $410 million funding round.[\[54\]](https://en.wikipedia.org#cite_note-57)

In March 2024, the company became a public company via an initial public offering, raising $600 million.[\[55\]](https://en.wikipedia.org#cite_note-58)<sup>[\[56\]](https://en.wikipedia.org#cite_note-59)</sup> On its first day of trading, it had a market capitalization of $9.5 billion.[\[57\]](https://en.wikipedia.org#cite_note-60)

## Site overview

Reddit is a website comprising user-generated content—including photos, videos, links, and text-based posts—and discussions of this content.[\[58\]](https://en.wikipedia.org#cite_note-Will_Nicol-2018-61)<sup>[\[59\]](https://en.wikipedia.org#cite_note-Michael_Franco-2018-62)</sup> The name "Reddit" is a play-on-words with the phrase "read it", i.e., "I read it on Reddit."[\[60\]](https://en.wikipedia.org#cite_note-63)<sup>[\[61\]](https://en.wikipedia.org#cite_note-64)</sup> According to Reddit, in 2019, there were approximately 430 million monthly users,<sup>[\[62\]](https://en.wikipedia.org#cite_note-65)</sup> who are known as "redditors".<sup>[\[47\]](https://en.wikipedia.org#cite_note-Pardes-2018b-50)</sup> The site's content is divided into categories or communities known on-site as "subreddits", of which there are more than 138,000 active communities.[\[63\]](https://en.wikipedia.org#cite_note-Molina-2017-66)

As a network of communities, Reddit's core content consists of posts from its users.[\[58\]](https://en.wikipedia.org#cite_note-Will_Nicol-2018-61)<sup>[\[59\]](https://en.wikipedia.org#cite_note-Michael_Franco-2018-62)</sup> Users can comment on others' posts to continue the conversation.<sup>[\[58\]](https://en.wikipedia.org#cite_note-Will_Nicol-2018-61)</sup> A key feature to Reddit is that users can cast positive or negative votes, called upvotes and downvotes respectively, for each post and comment on the site.<sup>[\[58\]](https://en.wikipedia.org#cite_note-Will_Nicol-2018-61)</sup> The number of upvotes or downvotes determines the posts' visibility on the site, so the most popular content is displayed to the most people.<sup>[\[58\]](https://en.wikipedia.org#cite_note-Will_Nicol-2018-61)</sup> Users can also earn "karma" for their posts and comments, a status that reflects their standing within the community and their contributions to Reddit.<sup>[\[58\]](https://en.wikipedia.org#cite_note-Will_Nicol-2018-61)</sup> Posts are sometimes automatically archived after six months, meaning they can no longer be commented or voted on.[\[64\]](https://en.wikipedia.org#cite_note-67)

The most popular posts from the site's numerous subreddits are visible on the front page to those who browse the site without an account.[\[63\]](https://en.wikipedia.org#cite_note-Molina-2017-66)<sup>[\[65\]](https://en.wikipedia.org#cite_note-Rich_McCormick-2017-68)</sup> By default for those users, the front page will display the subreddit r/popular, featuring top-ranked posts across all of Reddit, excluding not-safe-for-work communities and others that are most commonly filtered out by users (even if they are safe for work).[\[66\]](https://en.wikipedia.org#cite_note-69)<sup>[\[67\]](https://en.wikipedia.org#cite_note-70)</sup> The subreddit r/all originally did not filter topics,<sup>[\[68\]](https://en.wikipedia.org#cite_note-Shah-2017-71)</sup> but as of 2021 it does not include not-safe-for-work content.<sup>[\[69\]](https://en.wikipedia.org#cite_note-72)</sup> Registered users who subscribe to subreddits see the top content from the subreddits to which they subscribe on their personal front pages.[\[63\]](https://en.wikipedia.org#cite_note-Molina-2017-66)<sup>[\[65\]](https://en.wikipedia.org#cite_note-Rich_McCormick-2017-68)</sup> Additionally, some subreddits have a karma and account age requirement to discourage bots and spammers from posting.[\[70\]](https://en.wikipedia.org#cite_note-73)

Front-page rank, for both the general front page and for individual subreddits, is determined by a combination of factors, including the age of the submission, positive ("upvoted") to negative ("downvoted") feedback ratio, and the total vote-count.[\[71\]](https://en.wikipedia.org#cite_note-74)

### Users and moderators

Registering an account with Reddit is free and requires an email address. In addition to commenting and voting, registered users can also create their own subreddit on a topic of their choosing.<sup>[\[72\]](https://en.wikipedia.org#cite_note-75)</sup> In Reddit style, usernames begin with "u/". Noteworthy redditors include u/Poem\_for\_your\_sprog, who responds to messages across Reddit in verse,<sup>[\[73\]](https://en.wikipedia.org#cite_note-76)</sup> u/Shitty\_Watercolour (Hector Janse van Rensburg) who posts paintings in response to posts,<sup>[\[74\]](https://en.wikipedia.org#cite_note-77)</sup> and u/spez (Steve Huffman), the CEO of Reddit.

Subreddits are overseen by moderators, Reddit users who earn the title by creating a subreddit or being promoted by a current moderator.<sup>[\[63\]](https://en.wikipedia.org#cite_note-Molina-2017-66)</sup> Reddit users may also request to moderate a sub that has no moderators or very inactive ones in r/redditrequest. These requests are reviewed by the Reddit admins. Moderators are volunteers who manage their communities, set and enforce community-specific rules, remove posts and comments that violate these rules, and often work to keep discussions in their subreddit on topic.[\[63\]](https://en.wikipedia.org#cite_note-Molina-2017-66)[\[13\]](https://en.wikipedia.org#cite_note-Renfro-2016-16)<sup>[\[75\]](https://en.wikipedia.org#cite_note-78)</sup> Admins, by contrast, are employees of Reddit.[\[13\]](https://en.wikipedia.org#cite_note-Renfro-2016-16)

Early on, Reddit implemented shadow banning, purportedly to address spam accounts, while saying, "it's still the only tool we have to punish people who break the rules".[\[76\]](https://en.wikipedia.org#cite_note-79)<sup>[\[77\]](https://en.wikipedia.org#cite_note-80)</sup> In 2015, Reddit added an account suspension feature which it said would replace sitewide shadowbans, however, moderators are still able to shadowban users or their individual posts.[\[78\]](https://en.wikipedia.org#cite_note-81)

Reddit releases transparency reports annually which have information like how many posts have been taken down by moderators and for what reason. It also details information about requests law enforcement agencies have made for information about users or to take down content.<sup>[\[79\]](https://en.wikipedia.org#cite_note-82)</sup> In 2020, Reddit removed 6% of posts made on the platform (approx. 233 million). More than 99% of removals were marked as spam; the remainder made up of a mix of other offensive content. Around 131 million posts were removed by the automated moderator (\~56 %) and the rest were taken down manually.[\[80\]](https://en.wikipedia.org#cite_note-83)[\[81\]](https://en.wikipedia.org#cite_note-84)

It is estimated that Reddit's moderators work 466 hours every day, which is $3.4 million in unpaid work each year.<sup>[\[82\]](https://en.wikipedia.org#cite_note-Stokel-Walker-85)</sup> That roughly equates to 2.8% of the company's annual revenue.[\[82\]](https://en.wikipedia.org#cite_note-Stokel-Walker-85)

### Subreddits

Subreddits (officially called communities) are user-created areas of interest where discussions on Reddit are organized. There are about 138,000 active subreddits (among a total of 1.2 million) as of July 2018.[\[83\]](https://en.wikipedia.org#cite_note-Marotti-2018-86)<sup>[\[84\]](https://en.wikipedia.org#cite_note-87)</sup> Subreddit names begin with "r/"; for instance, "r/science" is a community devoted to discussing scientific publications, while "r/gaming" is a community devoted to discussing video games, and "r/worldnews" is for posting news articles from around the world.

In a 2014 interview with Memeburn, Erik Martin, then the general manager of Reddit, remarked that its "approach is to give the community moderators or curators as much control as possible so that they can shape and cultivate the type of communities they want".<sup>[\[85\]](https://en.wikipedia.org#cite_note-88)</sup> Subreddits often use themed variants of Reddit's alien mascot, Snoo, in the visual styling of their communities.[\[86\]](https://en.wikipedia.org#cite_note-Klara-2015-89)

#### Individual subreddits

The following is a nonexhaustive list of notable individual subreddits:

- r/AmItheAsshole – Reddit forum for judgement of behavior
- r/anime – Anime community on Reddit
- r/antiwork – Subreddit associated with the anti-work movement
- r/Art – Art internet forum
- r/AskHistorians – History forum on Reddit
- r/AskReddit – Subreddit providing a forum for users to ask questions
- r/bald – Subreddit about baldness and hair loss
- r/BreadStapledToTrees – Humorous subreddit where users staple bread to trees
- r/changemyview – Subreddit dedicated to presenting opposing viewpoints

- r/dataisbeautiful – Subreddit focused on data visualization
- r/The\_Donald – Banned Donald Trump-supporting subreddit
- r/Feminism – Feminist subreddit
- r/HaveWeMet – Reddit roleplay community
- r/IAmA

[content truncated; raise max_chars or request the source URL for more]

Sources:
- https://en.wikipedia.org/wiki/Public_company
- https://en.wikipedia.org/wiki/Social_news_website
- https://en.wikipedia.org/wiki/Multilingual
- https://en.wikipedia.org/wiki/Ticker_symbol
- https://en.wikipedia.org/wiki/New_York_Stock_Exchange
- https://www.nyse.com/quote/XNYS:RDDT
- https://en.wikipedia.org/wiki/Russell_1000
- https://en.wikipedia.org/wiki/S&P_500
- https://en.wikipedia.org/wiki/San_Francisco
- https://en.wikipedia.org/wiki/China
- https://en.wikipedia.org/wiki/North_Korea
- https://en.wikipedia.org/wiki/Advance_Publications
- https://en.wikipedia.org/wiki/Tencent
- https://en.wikipedia.org/wiki/Sam_Altman
- https://en.wikipedia.org/wiki/Organizational_founder
- https://en.wikipedia.org/wiki/Steve_Huffman
- https://en.wikipedia.org/wiki/CEO
- https://en.wikipedia.org/wiki/Jen_Wong
- https://en.wikipedia.org/wiki/Chief_operating_officer
- https://en.wikipedia.org/wiki/Chief_financial_officer
- https://en.wikipedia.org/wiki/Christopher_Slowe
- https://en.wikipedia.org/wiki/Chief_technology_officer
- https://en.wikipedia.org/wiki/Paul_Cappuccio?action=edit&redlink=1
- https://en.wikipedia.org/wiki/Chief_legal_officer
- https://en.wikipedia.org/wiki/United_States_dollar
- https://www.reddit.com/
- https://redditinc.com
- https://en.wikipedia.org/wiki/Banner_ads
- https://en.wikipedia.org/wiki/Daily_active_users
- https://en.wikipedia.org/wiki/Help:IPA/English
- https://en.wikipedia.org/wiki/File:LL-Q1860_(eng)-Flame,_not_lame-Reddit.wav
- https://en.wikipedia.org/wiki/Help:Pronunciation_respelling_key
- https://en.wikipedia.org/wiki/Proprietary_software
- https://en.wikipedia.org/wiki/News_aggregator
- https://en.wikipedia.org/wiki/Internet_forum
- https://en.wikipedia.org/wiki/Social_media
- https://en.wikipedia.org/wiki/Hyperlink
- https://en.wikipedia.org/wiki/Image
- https://en.wikipedia.org/wiki/Video
- https://en.wikipedia.org/wiki/Volunteering

[1549 source links omitted by the link cap]
