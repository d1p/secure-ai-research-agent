# Coroutines and tasks — Python 3.15.2 documentation

## Coroutines and tasks ¶

> This section outlines high-level asyncio APIs to work with coroutines and Tasks. Coroutines, Awaitables, Creating tasks, Task cancellation, Task groups, Sleeping, Running tasks concurrently, Eager ... This section outlines high-level asyncio APIs to work with coroutines and Tasks. Coroutines, Awaita

Source: https://docs.python.org/3/library/asyncio-task.html

# Coroutines and tasks¶

This section outlines high-level asyncio APIs to work with coroutines and Tasks.

## Coroutines¶

**Source code:** Lib/asyncio/coroutines.py

Coroutines declared with the async/await syntax is the
preferred way of writing asyncio applications.  For example, the following
snippet of code prints “hello”, waits 1 second,
and then prints “world”:

```
>>> import asyncio
>>> async def main():
...     print('hello')
...     await asyncio.sleep(1)
...     print('world')
>>> asyncio.run(main())
hello
world
```
Note that simply calling a coroutine will not schedule it to be executed:

```
>>> main()
<coroutine object main at 0x1053bb7c8>
```
To actually run a coroutine, asyncio provides the following mechanisms:

- The `asyncio.run()` function to run the top-level
entry point “main()” function (see the above example.)
- Awaiting on a coroutine.  The following snippet of code will
print “hello” after waiting for 1 second, and then print “world”
after waiting for *another* 2 seconds:
import asyncio import time async def say\_after(delay, what): await asyncio.sleep(delay) print(what) async def main(): print(f"started at {time.strftime('%X')}") await say\_after(1, 'hello') await say\_after(2, 'world') print(f"finished at {time.strftime('%X')}") asyncio.run(main()) Expected output: started at 17:13:52 hello world finished at 17:13:55
- The `asyncio.create_task()` function to run coroutines
concurrently as asyncio `Tasks`.
Let’s modify the above example and run two `say_after` coroutines *concurrently*:
async def main(): task1 = asyncio.create\_task( say\_after(1, 'hello')) task2 = asyncio.create\_task( say\_after(2, 'world')) print(f"started at {time.strftime('%X')}") # Wait until both tasks are completed (should take # around 2 seconds.) await task1 await task2 print(f"finished at {time.strftime('%X')}") Note that expected output now shows that the snippet runs 1 second faster than before: started at 17:14:32 hello world finished at 17:14:34
- The `asyncio.TaskGroup` class provides a more modern
alternative to `create_task()`.
Using this API, the last example becomes:
async def main(): async with asyncio.TaskGroup() as tg: task1 = tg.create\_task( say\_after(1, 'hello')) task2 = tg.create\_task( say\_after(2, 'world')) print(f"started at {time.strftime('%X')}") # The await is implicit when the context manager exits. print(f"finished at {time.strftime('%X')}") The timing and output should be the same as for the previous version. Added in version 3.11: `asyncio.TaskGroup`.

## Awaitables¶

We say that an object is an **awaitable** object if it can be used
in an `await` expression.  Many asyncio APIs are designed to
accept awaitables.

There are three main types of *awaitable* objects:
**coroutines**, **Tasks**, and **Futures**.

Coroutines

Python coroutines are *awaitables* and therefore can be awaited from
other coroutines:

```
import asyncio
async def nested():
    return 42
async def main():
    # Nothing happens if we just call "nested()".
    # A coroutine object is created but not awaited,
    # so it *won't run at all*.
    nested()  # will raise a "RuntimeWarning".
    # Let's do it differently now and await it:
    print(await nested())  # will print "42".
asyncio.run(main())
```
Important

In this documentation the term “coroutine” can be used for two closely related concepts:

- a *coroutine function*: an `async def` function;
- a *coroutine object*: an object returned by calling a *coroutine function*.

Tasks

*Tasks* are used to schedule coroutines *concurrently*.

When a coroutine is wrapped into a *Task* with functions like
`asyncio.create_task()` the coroutine is automatically
scheduled to run soon:

```
import asyncio
async def nested():
    return 42
async def main():
    # Schedule nested() to run soon concurrently
    # with "main()".
    task = asyncio.create_task(nested())
    # "task" can now be used to cancel "nested()", or
    # can simply be awaited to wait until it is complete:
    await task
asyncio.run(main())
```
Futures

A `Future` is a special **low-level** awaitable object that
represents an **eventual result** of an asynchronous operation.

When a Future object is *awaited* it means that the coroutine will
wait until the Future is resolved in some other place.

Future objects in asyncio are needed to allow callback-based code to be used with async/await.

Normally **there is no need** to create Future objects at the
application level code.

Future objects, sometimes exposed by libraries and some asyncio APIs, can be awaited:

```
async def main():
    await function_that_returns_a_future_object()
    # this is also valid:
    await asyncio.gather(
        function_that_returns_a_future_object(),
        some_python_coroutine()
    )
```
A good example of a low-level function that returns a Future object
is `loop.run_in_executor()`.

## Creating tasks¶

**Source code:** Lib/asyncio/tasks.py

-
asyncio.create\_task(*coro*, *\**, *name=None*, *context=None*, *eager\_start=None*, *\*\*kwargs*)¶
- Wrap the *coro* coroutine into a `Task` and schedule its execution.  Return the Task object.
The full function signature is largely the same as that of the
`Task` constructor (or factory) - all of the keyword arguments to
this function are passed through to that interface.
An optional keyword-only *context* argument allows specifying a
custom `contextvars.Context` for the *coro* to run in.
The current context copy is created when no *context* is provided.
An optional keyword-only *eager\_start* argument allows specifying
if the task should execute eagerly during the call to create\_task,
or be scheduled later. If *eager\_start* is not passed the mode set
by `loop.set_task_factory()` will be used.
The task is executed in the loop returned by `get_running_loop()`, `RuntimeError` is raised if there is no running loop in
current thread.
Note `asyncio.TaskGroup.create_task()` is a new alternative
leveraging structural concurrency; it allows for waiting
for a group of related tasks with strong safety guarantees.
Important Save a reference to the result of this function, to avoid a task disappearing mid-execution. The event loop only keeps weak references to tasks. A task that isn’t referenced elsewhere may get garbage collected at any time, even before it’s done. For reliable “fire-and-forget” background tasks, gather them in a collection: background\_tasks = set() for i in range(10): task = asyncio.create\_task(some\_coro(param=i)) # Add task to the set. This creates a strong reference. background\_tasks.add(task) # To prevent keeping references to finished tasks forever, # make each task remove its own reference from the set after # completion: task.add\_done\_callback(background\_tasks.discard) Note that this approach never awaits the tasks, so if a task
fails, its exception is never retrieved and asyncio logs a
“Task exception was never retrieved” message when the task is
garbage collected.  To avoid this, use `asyncio.TaskGroup` which keeps a strong reference to each task, awaits them and
propagates their exceptions:
async with asyncio.TaskGroup() as tg: for i in range(10): tg.create\_task(some\_coro(param=i)) Added in version 3.7. Changed in version 3.8: Added the *name* parameter.
Changed in version 3.11: Added the *context* parameter.
Changed in version 3.14: Added the *eager\_start* parameter by passing on all *kwargs*.

## Task cancellation¶

Tasks can easily and safely be cancelled.
When a task is cancelled, `asyncio.CancelledError` will be raised
in the task at the next opportunity.

It is recommended that coroutines use `try/finally` blocks to robustly
perform clean-up logic. In case `asyncio.CancelledError`
is explicitly caught, it should generally be propagated when
clean-up is complete. `asyncio.CancelledError` directly subclasses
`BaseException` so most code will not need to be aware of it.

The asyncio components that enable structured concurrency, like
`asyncio.TaskGroup` and `asyncio.timeout()`,
are implemented using cancellation internally and might misbehave if
a coroutine swallows `asyncio.CancelledError`. Similarly, user code
should not generally call `uncancel`.
However, in cases when suppressing `asyncio.CancelledError` is
truly desired, it is necessary to also call `uncancel()` to completely
remove the cancellation state.

## Task groups¶

Task groups combine a task creation API with a convenient and reliable way to wait for all tasks in the group to finish.

- *class* asyncio.TaskGroup¶
- An asynchronous context manager holding a group of tasks.
Tasks can be added to the group using `create_task()`.
All tasks are awaited when the context manager exits.
Added in version 3.11.
  -
create\_task(*coro*, *\**, *name=None*, *context=None*, *eager\_start=None*, *\*\*kwargs*)¶
  - Create a task in this task group.
The signature matches that of `asyncio.create_task()`.
If the task group is inactive (e.g. not yet entered,
already finished, or in the process of shutting down),
we will close the given `coro` and raise `RuntimeError`.
Changed in version 3.13: Close the given coroutine if the task group is not active. Changed in version 3.14: Passes on all *kwargs* to `loop.create_task()`
  -
cancel()¶
  - Cancel the task group. This is a non-exceptional, early exit of the task group’s lifetime – useful once the group’s goal has been met or its services no longer needed. `cancel()` will be called on any tasks in the group that
aren’t yet done, as well as the parent (body) of the group.  The task group
context manager will exit *without* `asyncio.CancelledError` being raised.
If `cancel()` is called before entering the task group, the group will be
cancelled upon entry.  This is useful for patterns where one piece of
code passes an unused `asyncio.TaskGroup` instance to another in order to have
the ability to cancel anything run within the group.
`cancel()` is idempotent and may be called after the task group has
already exited.
Some ways to use `cancel()`:
    - call it from the task group body based on some condition or event
    - pass the task group instance to child tasks via `create_task()`, allowing a child
task to conditionally cancel the entire group
    - pass the task group instance or bound `cancel()` method to some other task *before* opening the task group, allowing remote cancellation
Added in version 3.15.

Example:

```
async def main():
    async with asyncio.TaskGroup() as tg:
        task1 = tg.create_task(some_coro(...))
        task2 = tg.cre

[content truncated; raise max_chars or request the source URL for more]

Sources:
- https://docs.python.org#coroutines-and-tasks
- https://docs.python.org#id2
- https://docs.python.org#coroutines
- https://github.com/python/cpython/tree/3.15/Lib/asyncio/coroutines.py
- https://docs.python.org/glossary.html#term-coroutine
- https://docs.python.org/asyncio-runner.html#asyncio.run
- https://docs.python.org#asyncio.create_task
- https://docs.python.org#asyncio.Task
- https://docs.python.org#asyncio.TaskGroup
- https://docs.python.org#id3
- https://docs.python.org#awaitables
- https://docs.python.org/reference/expressions.html#await
- https://docs.python.org/reference/compound_stmts.html#async-def
- https://docs.python.org/asyncio-future.html#asyncio.Future
- https://docs.python.org/asyncio-eventloop.html#asyncio.loop.run_in_executor
- https://docs.python.org#id4
- https://docs.python.org#creating-tasks
- https://github.com/python/cpython/tree/3.15/Lib/asyncio/tasks.py
- https://docs.python.org#coroutine
- https://docs.python.org/contextvars.html#contextvars.Context

[98 source links omitted by the link cap]
