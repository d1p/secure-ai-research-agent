# Künstliche Intelligenz – Wikipedia

## Künstliche Intelligenz

Source: https://de.wikipedia.org/wiki/K%C3%BCnstliche_Intelligenz

**Künstliche Intelligenz** (kurz **KI**, englisch artificial intelligence, kurz *AI*) ist ein Forschungs- und Anwendungsgebiet der Informatik. Es handelt sich dabei um verschiedene Klassen von Problemlösungsverfahren, die anhand von Eingaben aus ihrer Umgebung Handlungen ausführen.[\[1.1\]](https://de.wikipedia.org#cite_note-2)

## Beschreibung

\[Bearbeiten|

Quelltext bearbeiten\]

Historisch ist der Begriff nicht einheitlich definiert, sondern kann sich einerseits auf „Intelligenz“ im Sinne der Nachbildung menschlichen Verhaltens beispielsweise bei der Bilderkennung oder der Interaktion in menschlicher Sprache beziehen, andererseits auf die Fähigkeit zu rationalem, logikbasiertem Schlussfolgern. In der öffentlichen Wahrnehmung werden häufig maschinelles Lernen und die auf diesem Prinzip aufbauenden Chatbots mit dem Begriff der künstlichen Intelligenz gleichgesetzt. Maschinelles Lernen ist jedoch nur eines von mehreren Teilgebieten des Feldes; ihm stehen beispielsweise traditionelle logik- und regelbasierte Ansätze wie die der symbolischen künstlichen Intelligenz gegenüber,<sup>[\[1.2\]](https://de.wikipedia.org#cite_note-3)</sup> welche ergänzend auch in Chatbots zum Einsatz kommen.[\[2\]](https://de.wikipedia.org#cite_note-4)

Im Laufe der Zeit haben sich innerhalb der KI-Forschung zahlreiche Teilgebiete und Methoden herausgebildet. Zudem wird unterschieden, welche Probleme mit den Methoden der KI gelöst werden sollen. Dabei werden zwei Bereiche unterschieden: *schwache KI* und *starke KI*.

Die angewandte Informatik befasst sich damit, wie solche Systeme entwickelt und umgesetzt werden können. Beispiele dafür sind Multiagentensysteme, Expertensysteme, Transformer und serviceorientierte Architekturen.

## Geschichte

\[Bearbeiten|

Quelltext bearbeiten\]

### Begriffsherkunft

\[Bearbeiten|

Quelltext bearbeiten\]

Der Begriff *artificial intelligence* (*künstliche Intelligenz*) wurde 1955 vom US-amerikanischen Informatiker John McCarthy im Rahmen eines Förderantrags an die Rockefeller-Stiftung für das Dartmouth Summer Research Project on Artificial Intelligence geprägt, ein Forschungsprojekt, bei dem sich im Sommer 1956 eine Gruppe von zehn Wissenschaftlern über ca. acht Wochen mit der Thematik befasste.[\[3\]](https://de.wikipedia.org#cite_note-5)[\[4\]](https://de.wikipedia.org#cite_note-Spektrum_Lexikon_Neuro-6)

Die Wahl des Begriffs „Künstliche Intelligenz“ wurde im Lauf der Zeit verschiedentlich diskutiert. Der Computerpionier Douglas Engelbart zog bereits 1962 den Begriff „Intelligence Augmentation“ vor. Seiner Ansicht nach sei das Ziel, durch geeignete Interaktionsparadigmen das Können und Verständnis des mit dem Computer interagierenden Menschen zu verstärken, anstatt lediglich menschliche Aufgaben zu automatisieren.[\[1.3\]](https://de.wikipedia.org#cite_note-7)[\[5\]](https://de.wikipedia.org#cite_note-8)

### Vorläufer

\[Bearbeiten|

Quelltext bearbeiten\]

Künstliche neuronale Netze (KNN) im Sinne von Warren McCulloch und Walter Pitts (1943),[\[6\]](https://de.wikipedia.org#cite_note-9)Alan Turings Überlegungen zur maschinellen Intelligenz (siehe auch Turing-Test)<sup>[\[7\]](https://de.wikipedia.org#cite_note-turing-10)</sup> um 1950 und Frank Rosenblatts Implementierungen des Perzeptrons<sup>[\[8\]](https://de.wikipedia.org#cite_note-11)</sup> ab 1957 waren Vorläufer zur Entwicklung der Künstlichen Intelligenz.<sup>[\[9.1\]](https://de.wikipedia.org#cite_note-13)</sup> Die Hoffnungen von Expertensystemen, u. a. Mycin zur Diagnose und Therapie von Infektionskrankheiten ab Anfang der 1970er Jahre, erfüllten sich nicht und führten zum ersten KI-Winter. Verbesserte Expertensysteme in den 1980ern, vor allem aufgrund erhöhter Rechenleistung, und Verfahren zum Training mehrschichtiger Netze (u. a. Paul Werbos), heute als Backpropagation bekannt, förderten einen neuen Aufschwung in der Forschung an künstlichen neuronalen Netzen. Aber auch diese Erwartungen wurden verfehlt und führten ab Ende der 1980er zum zweiten KI-Winter durch ökonomische Blasen, da sich keine nachhaltigen Geschäftsmodelle erzielen ließen. Erfolge durch maschinelles Lernen, u. a. Deep-Learning-Ansätze mittels Deep Blue für Schach (1997) und AlphaGo für Go (2017), führten zu einer allmählichen Erholung und allgemein sichtbaren Erfolgen bis zum endgültigen Durchbruch der Large Language Models (LLM) 2022.

## Definitionen und Kategorien Künstlicher Intelligenz

\[Bearbeiten|

Quelltext bearbeiten\]

Der Begriff der künstlichen Intelligenz wird in der Forschung anhand unterschiedlicher Kriterien und Zielvorstellungen definiert. Je nach Sichtweise wird der Begriff in Industrie, Gesellschaft und Politik teilweise über diese wissenschaftlichen Grundlagen definiert, oder aber über die zu erzielenden Anwendungen. Die Bestimmung des Gegenstands wird dadurch erschwert, dass bereits der zugrunde liegende Begriff der Intelligenz auch in der Psychologie nicht einheitlich definiert ist. Legg und Hutter stellten in einer Übersicht zahlreiche Definitionen aus Psychologie, Philosophie und KI-Forschung zusammen und hielten fest, dass es trotz langer Forschungstradition keine allgemein akzeptierte Standarddefinition von Intelligenz gibt.[\[10\]](https://de.wikipedia.org#cite_note-14)

### Definitionskategorien nach Russell und Norvig

\[Bearbeiten|

Quelltext bearbeiten\]

Stuart J. Russell und Peter Norvig unterscheiden in ihrem Standardwerk *Künstliche Intelligenz: Ein moderner Ansatz* die verschiedenen Ansätze und Ausprägungen von KI-Systemen anhand von vier Kategorien:[\[1\]](https://de.wikipedia.org#cite_note-:6-1)

- Nachbildung menschlichen Verhaltens
- Nachbildung menschlichen Denkens
- Nachbildung rationalen Denkens
- Nachbildung rationalen Verhaltens

Diese vier Kategorien lassen sich anhand zweier Dimensionen einordnen: Eine Achse stellt den symbolischen bzw. logikbasierten Ansatz dem heuristischen Ansatz mit der Nachbildung neuronaler Netze gegenüber. Die andere Achse stellt die Simulationsmethode einer Konzentration auf das phänomenologisch beobachtbare Verhalten gegenüber.

Neuronale KI-Methoden verfolgen einen Bottom-up-Ansatz und versuchen, die Funktionen des menschlichen Gehirns über mathematische Verfahren zu approximieren oder gar möglichst präzise nachzubilden. Die symbolische KI verfolgt umgekehrt einen Top-down-Ansatz und nähert sich den Intelligenzleistungen von einer begrifflichen Ebene her. Die Simulationsmethode orientiert sich so nah wie möglich an den tatsächlichen kognitiven Prozessen des Menschen. Dagegen kommt es dem phänomenologischen Ansatz nur auf das Ergebnis an.

Viele ältere Methoden, die in der KI entwickelt wurden, basieren auf heuristischen Lösungsverfahren. In jüngerer Zeit spielen mathematisch fundierte Ansätze aus der Statistik, der mathematischen Programmierung und der Approximationstheorie eine bedeutende Rolle.

Die Kategorien nach Russell und Norvig im Einzelnen:

#### Nachbildung menschlichen Verhaltens

\[Bearbeiten|

Quelltext bearbeiten\]

Alan Turing schlug den nach ihm benannten Turing-Test als Kriterium dafür vor, ob eine Maschine intelligentes Verhalten zeigt, das dem eines Menschen gleichwertig ist. Dazu stellt ein Mensch per Terminal (Bildschirm und Tastatur, oder auch Lautsprecher und Mikrofon) beliebige Fragen, ohne dabei zu wissen, ob diese von einem anderen Menschen oder einer Maschine beantwortet werden. Der Fragesteller muss danach entscheiden, ob es sich beim Interviewpartner um eine Maschine oder einen Menschen handelte. Ist die Maschine nicht von einem Menschen zu unterscheiden, erfüllt sie laut Turing das Kriterium für Intelligenz.<sup>[\[7\]](https://de.wikipedia.org#cite_note-turing-10)</sup> Ziel ist hier also ein phänomenologisch beobachtbares Verhalten, das nicht von dem eines Menschen unterscheidbar sein soll. Seit 1991 existiert der Loebner-Preis für den Turing-Test.[\[11\]](https://de.wikipedia.org#cite_note-15)

#### Nachbildung menschlichen Denkens

\[Bearbeiten|

Quelltext bearbeiten\]

Dieser Ansatz ist mit den Kognitionswissenschaften verknüpft und zielt darauf ab, die Mechanismen menschlichen Denkens nachzuvollziehen und maschinell zu modellieren. Die Theorie ist, dass auf Basis einer hinreichend präzisen Theorie menschlicher Kognition die damit verbundenen Abläufe programmatisch simuliert werden können. Hierfür werden die tatsächlichen Abläufe im Gehirn bei Denkprozessen experimentell ermittelt und beschrieben, um sie in Software nachbilden zu können. Sobald die Ausgaben solch eines Systems nicht von menschlichen Reaktionen auf dieselben Ausgangssituationen unterscheidbar sind, könnten diese Mechanismen auch in einem menschlichen Gehirn ablaufen.

In der Frühzeit der KI-Forschung wurden die beiden vorangegangenen Ansätze häufig gleichbedeutend verwendet: Wenn ein Algorithmus eine gestellte Aufgabe überzeugend löste, wurde dies als Indiz angesehen, dass der Algorithmus auch die Abläufe im Gehirn gut modelliere, oder andersherum. Mittlerweile werden diese beiden Ansätze als getrennte Herangehensweisen unterschieden.[\[1.4\]](https://de.wikipedia.org#cite_note-16)

#### Nachbildung rationalen Denkens

\[Bearbeiten|

Quelltext bearbeiten\]

Bei diesem Ansatz werden Aussagen nach formalen Regeln abgebildet, um sie nach den Regeln der Logik auswerten zu können. Bereits 1965 war es möglich, jegliches (prinzipiell lösbare Problem) zu lösen, das in formaler Semantik notiert ist.<sup>[\[1.5\]](https://de.wikipedia.org#cite_note-17)</sup> Ziel hierbei ist es, logische Schlüsse ziehen zu können. Nach Russell und Norvig eignet sich diese Herangehensweise dafür, auch komplexe Zusammenhänge logisch erschließen zu können – nicht jedoch zur Nachbildung „intelligenten Verhaltens“.

Aus diesem Feld ging die Klasse der logischen Programmiersprachen hervor.

#### Nachbildung rationalen Verhaltens

\[Bearbeiten|

Quelltext bearbeiten\]

Laut Russell und Norvig ist das Ziel hier, Handlungen eines Systems auf das beste oder erwartbar beste Ergebnis hin zu optimieren.

### Starke und schwache KI

\[Bearbeiten|

Quelltext bearbeiten\]

Starke KI wären kognitive Systeme, die auf Augenhöhe mit Menschen die Arbeit zur Erledigung schwieriger Aufgaben übernehmen können. Demgegenüber geht es bei schwacher KI darum, konkrete Anwendungsprobleme zu meistern. Das menschliche Denken und technische Anwendungen sollen hier in Einzelbereichen unterstützt werden.[\[12\]](https://de.wikipedia.org#cite_note-Nilsson-2009-18)

Die Fähigkeit zu lernen ist eine wichtige Eigenschaft vieler KI-Systeme. Ein weiteres wichtiges Merkmal ist die Fähigkeit eines KI-Systems, mit Unsicherheiten und Wahrscheinlichkeiten (sowie mit *probabilistischen Informationen*) umzugehen.<sup>[\[13\]](https://de.wikipedia.org#cite_note-:0-19)</sup> Insbesondere sind solche Anwendungen von Interesse, zu deren Lösung nach allgemeinem Verständnis eine Form von „Intelligenz“ notwendig zu sein scheint.[\[14\]](https://de.wikipedia.org#cite_note-20)

Letztlich geht es der schwachen KI somit um die Simulation intelligenten Verhaltens mit Mitteln der Mathematik und der Informatik, es geht ihr nicht um Schaffung von Bewusstsein oder um ein tieferes Verständnis von Intelligenz.<sup>[\[15\]](https://de.wikipedia.org#cite_note-Searle1980-21)</sup> Während die Frage nach der prinzipiellen Machbarkeit starker KI bis heute offen ist, sind bei der schwachen KI in den letzten Jahren bedeutende Fortschritte erzielt worden.

Unterschieden wird nach den Fragestellungen, die untersucht werden, nicht nach den verwendeten Methoden. Schwache KI ist stark in der Anwendung, erlaubt eine Monetarisierung und prägt das gesellschaftliche Verständnis. Beispiele sind die Autokorrektur bei der Texteingabe, die Spracherkennung für die Umwandlung von Sprache in Text, Systeme für autonomes Fahren<sup>[\[16\]](https://de.wikipedia.org#cite_note-22)</sup> und große Sprachmodelle.<sup>[\[17\]](https://de.wikipedia.org#cite_note-23)</sup> Starke KI befasst sich mit Grundsatzfragen wie der Beschreibung von Bewusstsein, der Repräsentation und Aktualisierung von Wissen (z. B. dem Umgang mit Widersprüchen) oder der Frage, was erforderlich ist, um Intelligenz nachzuweisen. Die beiden Bereiche lassen sich nicht scharf trennen. Methoden zur Problemanalyse können je nach Interpretation beiden Klassen zugeordnet werden. Mitunter wird die Frage, ob und wie eine Allgemeine künstliche Intelligenz oder eine Superintelligenz erzeugt werden kann, der starken KI zugeordnet.

Die philosophische Interpretation dieser Unterteilung umfasst zwei Auffassungen: Schwache KI kann handeln (etwa autonomes Fahren), jedoch ohne Bewusstsein; Vertreter der starken KI hingegen halten ein künstliches Bewusstsein für möglich. Welche Auffassung zutrifft, ist weiterhin ungeklärt.[\[15\]](https://de.wikipedia.org#cite_note-Searle1980-21)

Ein starkes KI-System muss nicht viel mit dem Menschen gemeinsam haben. Es wird wahrscheinlich eine andersartige kognitive Architektur aufweisen und auch in seinen Entwicklungsstadien nicht mit den evolutionären kognitiven Stadien des menschlichen Denkens vergleichbar sein (Evolution des Denkens). Vor allem ist nicht anzunehmen, dass eine künstliche Intelligenz Gefühle wie Liebe, Hass, Angst oder Freude besitzt.[\[18\]](https://de.wikipedia.org#cite_note-:1-24)

### EU-rechtliche Definition

\[Bearbeiten|

Quelltext bearbeiten\]

Die KI-Verordnung der EU definiert in Artikel 3 (Begriffsbestimmungen) ein „KI-System“ wie folgt:

„Für die Zwecke dieser Verordnung bezeichnet der Ausdruck \[…\] ‚KI-System‘ ein maschinengestütztes System, das für einen in unterschiedlichem Grade autonomen Betrieb ausgelegt ist und das nach seiner Betriebsaufnahme anpassungsfähig sein kann und das aus den erhaltenen Eingaben für explizite oder implizite Ziele ableitet, wie Ausgaben wie etwa Vorhersagen, Inhalte, Empfehlungen oder Entscheidungen erstellt werden, die physische oder virtuelle Umgebungen beeinflussen können“[\[19\]](https://de.wikipedia.org#cite_note-:2-25)

In Erwägungsgrund 12 werden die verwendeten Eingrenzungen erläutert und klargestellt, dass sich die Verordnung sowohl auf konnektionistische Systeme maschinellen Lernens als auch auf symbolische KI-Systeme bezieht:

„Zu den Techniken, die während der Gestaltung eines KI-Systems das Ableiten ermöglichen, gehören Ansätze für maschinelles Lernen, wobei aus Daten gelernt wird, wie bestimmte Ziele erreicht werden können, sowie logik- und wissensgestützte Konzepte, wobei aus kodierten Informationen oder symbolischen Darstellungen der zu lösenden Aufgabe abgeleitet wird.“[\[19\]](https://de.wikipedia.org#cite_note-:2-25)

### Eigenschaften von Intelligenz

\[Bearbeiten|

Quelltext bearbeiten\]

Versuchsweise wird Intelligenz definiert als die Eigenschaft, die ein Wesen befähigt, angemessen und vorausschauend in seiner Umgebung zu agieren. Dazu gehören die Fähigkeiten

- Umgebungsdaten wahrzunehmen, d. h. auf Stimuli zu reagieren
- Informationen
  - aufzunehmen,
  - zu verarbeiten und
  - als Wissen zu speichern,
- Sprache
  - zu verstehen und
  - zu erzeugen,
- Probleme zu lösen und zu handeln
- Ziele zu definieren, zu erreichen und zu modifizieren
- Autonom Entscheidungen zu treffen.

Praktische Erfolge der KI werden schnell in die Anwendungsbereiche integriert und werden dann von vielen nicht mehr als KI angesehen, auch wenn sie deren Definition erfüllen.<sup>[\[20\]](https://de.wikipedia.org#cite_note-:5-26)</sup> Dieses Phänomen wird auch als „AI effect“ bezeichnet.[\[20\]](https://de.wikipedia.org#cite_note-:5-26)

„Künstliche Intelligenz ist die Eigenschaft eines IT-Systems, ‚menschenähnliche‘, intelligente Verhaltensweisen zu zeigen.“

<sup>[\[21\]](https://de.wikipedia.org#cite_note-27)</sup>

„Die künstliche Intelligenz \[...\] ist ein Teilgebiet der Informatik, welches sich mit der Erforschung von Mechanismen des intelligenten menschlichen Verhaltens befasst \[...\].“

<sup>[\[4\]](https://de.wikipedia.org#cite_note-Spektrum_Lexikon_Neuro-6)</sup>

„Unter künstlicher Intelligenz (KI) verstehen wir Technologien, die menschliche Fähigkeiten im Sehen, Hören, Analysieren, Entscheiden und Handeln ergänzen und stärken.“

<sup>[\[22\]](https://de.wikipedia.org#cite_note-28)</sup>

„Künstliche Intelligenz ist die Fähigkeit einer Maschine, menschliche Fähigkeiten wie logisches Denken, Lernen, Planen und Kreativität zu imitieren.“

<sup>[\[23\]](https://de.wikipedia.org#cite_note-29)</sup>

## Metaphorik

\[Bearbeiten|

Quelltext bearbeiten\]

Der Diskurs über KI ist stark von einer metaphorischen Sprache geprägt.[\[24\]](https://de.wikipedia.org#cite_note-30)[\[25\]](https://de.wikipedia.org#cite_note-31)<sup>[\[26\]](https://de.wikipedia.org#cite_note-ReferenceA-32)</sup> Begriffe wie *künstliche Intelligenz* und *maschinelles Lernen* sind selbst anthropomorphe Metaphern, die auf die menschliche Kognition anspielen.

Eine weitere gängige Metapher ist die Black Box, die die Intransparenz vieler KI-Systeme beschreibt.<sup>[\[27\]](https://de.wikipedia.org#cite_note-33)</sup> Im wissenschaftlichen Diskurs werden große Sprachmodelle auch als stochastische Papageien bezeichnet, um darauf hinzuweisen, dass sie Texte erzeugen, ohne den Inhalt wirklich zu verstehen.<sup>[\[28\]](https://de.wikipedia.org#cite_note-34)</sup> Der Autor Ted Chiang vergleicht große Sprachmodelle mit einem unscharfen JPEG aus dem Netz, um Kompressionsmechanismen zu veranschaulichen.[\[29\]](https://de.wikipedia.org#cite_note-35)

Anthropomorphe Metaphern sind umstritten, da sie ein übertriebenes oder verzerrtes Bild von KI-Systemen vermitteln können.[\[30\]](https://de.wikipedia.org#cite_note-36)<sup>[\[31\]](https://de.wikipedia.org#cite_note-37)</sup> Alternativ diskutieren Forscher und Journalisten Metaphern wie KI als Werkzeuge,<sup>[\[32\]](https://de.wikipedia.org#cite_note-38)</sup> Spiegel,<sup>[\[33\]](https://de.wikipedia.org#cite_note-39)</sup> Tiere, Organismen oder Naturphänomene.<sup>[\[34\]](https://de.wikipedia.org#cite_note-40)</sup>
Die Wahl einer Metapher beeinflusst nicht nur das öffentliche Verständnis von KI,<sup>[\[35\]](https://de.wikipedia.org#cite_note-41)</sup> sondern spielt auch eine Rolle in der Gesetzgebung,<sup>[\[36\]](https://de.wikipedia.org#cite_note-42)</sup> Regulierung<sup>[\[37\]](https://de.wikipedia.org#cite_note-43)</sup> und wissenschaftlichen Forschung.[\[38\]](https://de.wikipedia.org#cite_note-44)

## Forschungsgebiete

\[Bearbeiten|

Quelltext bearbeiten\]

Neben den Forschungsergebnissen der Kerninformatik selbst sind in die Erforschung der KI Ergebnisse der Psychologie, Neurologie und Neurowissenschaften, der Mathematik und Logik, Kommunikationswissenschaft, Philosophie und Linguistik eingeflossen. Umgekehrt nahm die Erforschung der KI auch ihrerseits Einfluss auf andere Gebiete, vor allem auf die Neurowissenschaften. Dies zeigt sich in der Ausbildung des Bereichs der Neuroinformatik, der der biologieorientierten Informatik zugeordnet ist, sowie der Computational Neuroscience.

Bei künstlichen neuronalen Netzen handelt es sich um Techniken, die ab Mitte des 20. Jahrhunderts entwickelt wurden und auf der Neurophysiologie aufbauen.
KI stellt somit kein geschlossenes Forschungsgebiet dar. Vielmehr werden Techniken aus verschiedenen Disziplinen verwendet, ohne dass diese eine Verbindung miteinander haben müssen.

Wichtige Tagungen sind die International Joint Conference on Artificial Intelligence (IJCAI), die seit 1969 stattfindet und die seit 1982 von der Europäischen Vereinigung für künstliche Intelligenz (EurAI) organisierte European Conference on Artificial Intelligence (ECAI).

Seit der Begriffsprägung im Jahr 1955 hat sich eine Reihe relativ selbständiger Teildisziplinen herausgebildet:

- Mustererkennung, wozu auch Spracherkennung und Handschrifterkennung zählen;
- Software-Agent;
- Wissensmodellierung einschließlich Logischer Programmierung und Inferenzmaschinen;
- Expertensysteme, Frage-Antwort-Systeme und Chatbots;
- Maschinelles Lernen;
- Künstliche neuronale Netze und Deep Learning;
- Computer Vision;
- Robotik und
- Universelle Spieleprogramme.

Zur Forschungsrichtung künstliches Leben bestehen enge Beziehungen. Das Fernziel der KI ist die als starke KI oder künstliche allgemeine Intelligenz bezeichnete Fähigkeit eines intelligenten Agenten, jede intellektuelle Aufgabe zu verstehen oder zu erlernen, die der Mensch oder ein anderes Lebewesen bewältigen kann.

## Teilgebiete

\[Bearbeiten|

Quelltext bearbeiten\]

### Wissensbasierte Systeme

\[Bearbeiten|

Quelltext bearbeiten\]

Wissensbasierte Systeme modellieren eine Form rationaler Intelligenz für sogenannte Expertensysteme. Diese sind in der Lage, auf eine Frage des Anwenders auf Grundlage formalisierten Fachwissens und daraus gezogener logischer Schlüsse Antworten zu liefern. Beispielhafte Anwendungen finden sich in der Diagnose von Krankheiten oder der Suche und Beseitigung von Fehlern in technischen Systemen.

### Musteranalyse und Mustererkennung

\[Bearbeiten|

Quelltext bearbeiten\]

*Visuelle Intelligenz* ermöglicht es, Bilder bzw. Formen zu erkennen und zu analysieren. Als Anwendungsbeispiele seien hier Handschrifterkennung, Identifikation von Personen durch Gesichtserkennung, Abgleich der Fingerabdrücke oder der Iris, industrielle Qualitätskontrolle und Fertigungsautomation (letzteres in Kombination mit Erkenntnissen der Robotik) genannt.

Mittels *sprachlicher Intelligenz* ist es beispielsweise möglich, einen geschriebenen Text in gesprochene Sprache umzuwandeln (Sprachsynthese) und umgekehrt einen gesprochenen Text zu verschriftl

[content truncated; raise max_chars or request the source URL for more]

Sources:
- https://de.wikipedia.org/wiki/Englische_Sprache
- https://de.wikipedia.org/wiki/Informatik
- https://de.wikipedia.org/w/index.php?title=K%C3%BCnstliche_Intelligenz&veaction=edit§ion=1
- https://de.wikipedia.org/w/index.php?title=K%C3%BCnstliche_Intelligenz&action=edit§ion=1
- https://de.wikipedia.org/wiki/Maschinelles_Lernen
- https://de.wikipedia.org/wiki/Chatbot
- https://de.wikipedia.org/wiki/Symbolische_künstliche_Intelligenz
- https://de.wikipedia.org#Starke_und_schwache_KI
- https://de.wikipedia.org/wiki/Multiagentensystem
- https://de.wikipedia.org/wiki/Expertensystem
- https://de.wikipedia.org/wiki/Transformer_(Maschinelles_Lernen)
- https://de.wikipedia.org/wiki/Serviceorientierte_Architektur
- https://de.wikipedia.org/w/index.php?title=K%C3%BCnstliche_Intelligenz&veaction=edit§ion=2
- https://de.wikipedia.org/w/index.php?title=K%C3%BCnstliche_Intelligenz&action=edit§ion=2
- https://de.wikipedia.org/w/index.php?title=K%C3%BCnstliche_Intelligenz&veaction=edit§ion=3
- https://de.wikipedia.org/w/index.php?title=K%C3%BCnstliche_Intelligenz&action=edit§ion=3
- https://de.wikipedia.org/wiki/John_McCarthy
- https://de.wikipedia.org/wiki/Rockefeller-Stiftung
- https://de.wikipedia.org/wiki/Dartmouth_Conference
- https://de.wikipedia.org/wiki/Douglas_C._Engelbart
- https://de.wikipedia.org/w/index.php?title=K%C3%BCnstliche_Intelligenz&veaction=edit§ion=4
- https://de.wikipedia.org/w/index.php?title=K%C3%BCnstliche_Intelligenz&action=edit§ion=4
- https://de.wikipedia.org/wiki/Künstliches_neuronales_Netz
- https://de.wikipedia.org/wiki/Warren_McCulloch
- https://de.wikipedia.org/wiki/Walter_Pitts
- https://de.wikipedia.org/wiki/Alan_Turing
- https://de.wikipedia.org/wiki/Turing-Test
- https://de.wikipedia.org/wiki/Frank_Rosenblatt
- https://de.wikipedia.org/wiki/Perzeptron
- https://de.wikipedia.org/wiki/Mycin_(Expertensystem)
- https://de.wikipedia.org/wiki/KI-Winter
- https://de.wikipedia.org/wiki/Rechenleistung
- https://de.wikipedia.org/wiki/Paul_Werbos
- https://de.wikipedia.org/wiki/Backpropagation
- https://de.wikipedia.org/wiki/Spekulationsblase
- https://de.wikipedia.org/wiki/Geschäftsmodell
- https://de.wikipedia.org/wiki/Deep_Learning
- https://de.wikipedia.org/wiki/Deep_Blue
- https://de.wikipedia.org/wiki/Schach
- https://de.wikipedia.org/wiki/AlphaGo

[946 source links omitted by the link cap]
